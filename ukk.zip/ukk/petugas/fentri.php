<?php 
	session_start();
 
	// cek apakah yg mengakses halaman ini sdh login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=error");
	}
 
if(!isset($_SESSION['username'])){
    header("location:../login.php");
}

$nisn = $_GET['nisn'];
$kekurangan = $_GET['kekurangan'];
include('../conn.php');
$query = $conn->query("SELECT * FROM siswa,spp,kelas WHERE siswa.idkls=kelas.idkls AND siswa.idSpp=spp.idSpp AND nisn='$nisn'");
$data = $query->fetch();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="css/ind.css"> -->
    <link rel="stylesheet" href="css/entri.css">
    <link href="css/addentri.css" rel="stylesheet">

    <title>Petugas - Entri Transaksi Pembayaran</title>
</head>
<body >
    <div class="container">
        <div class="nav active">
            <ol>
            <ul>
            <li>
                <a href="#">
                    <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                    <span class="title">spp</span>
                    <br>
                 </a>
               
                </li>
                <li>
                <a href="index.php">
                    <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                    <span class="title">Dashboard</span>
                </a>
                </li>
                <li>
                <a href="entri.php">
                    <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                    <span class="title">Transaksi pembayaran</span>
                </a>
                </li>
                <li>
                <a href="lout.php">
                    <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                    <span class="title">Sign Out</span>
                </a>
                </li>
                <!-- name -->
                      <span class="name">
                    <?php
                    echo "Welcome, "; echo $_SESSION['username'];
                    ?></span>
               
            </ul>
            </ol>
        </div>

        <!-- main -->

        <div class= "main active" >
            <div class="topbar">
                <!-- toggle -->
                <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
                </div>
                <!-- search -->
                <form action="" method="post">
                <div class="search">
                    <label for="">
                        <input type="text" name="keyword" placeholder="Search here">
                        <!-- <button type="submit" name="search">cri</button> -->
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>
                </form>
                <!-- user -->
                <div class="user">
                        <a href="index.php">
                            <div class="prof">
                            <img src="../img/<?= $_SESSION['img'] ;?>" alt="">
                            </div>
                        </a>
                    </div>
                   
            </div>
            <!-- breadcrumb -->
            <nav aria-label="breadcrumb" class="crumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a> > <a href="entri.php"> Data Transaksi Pembayaran</a> > Entri Transaksi Pembayaran</li>
            </ol>
            </nav>

    <div class="kontainer">
        <header>Entri Transaksi Pembayaran</header>

        <form action="addent.php?nisn=<?= $nisn ?>" method="post">
        <input type="hidden" name="idSpp" value="<?= $data['idSpp'] ?>" required >
        <div class="input-field date-today">
                            <span style="line-height:3.5;">Tanggal Bayar :&nbsp;</span>
                            <!-- <input disabled type="date" name="tglBayar" value="<?php echo date('d/m/Y')?>" style="width:40%;float:right" class="form-control rounded-3" readonly ><ion-icon name="calendar-outline"></ion-icon> -->
                            <input type="text"  value="<?php echo date('d/m/Y')?>" id="date" name="tglBayar" style="width:13%;" placeholder="" readonly>
                            <!-- <input type="date"  id="date" name="tglBayar" placeholder="" required> -->
                            
                        </div>
    <div class="form-first">
        <div class="details personal">

            <div class="fields">
                <div class="input-field">
                <label for="">Nama Petugas</label>
                    <input  type="text" value="<?= $_SESSION['nama'] ?>" readonly required>
                </div>
                <div class="input-field">
                <label for="nisn">NISN Murid</label>
                    <input  type="text" value="<?= $data['nisn']; ?>" id="nisn" name="nisn" readonly required>
                </div>
                <div class="input-field">
                <label for="">Nama Murid</label>
                    <input  type="text" value="<?= $data['name']; ?>" id="name" readonly required>
                </div>

                <div class="input-field">
                <label for="bln">Bulan Dibayar</label>
                            <select name="bulan_dibayar" size="1" id="bln" required>
                            <option value="" selected disabled>Pilih bulan</option>
                            <option value="Januari">Januari</option>
                            <option value="Februari">Februari</option>
                            <option value="Maret">Maret</option>
                            <option value="April">April</option>
                            <option value="Mei">Mei</option>
                            <option value="Juni">Juni</option>
                            <option value="Juli">Juli</option>
                            <option value="Agustus">Agustus</option>
                            <option value="September">September</option>
                            <option value="Oktober">Oktober</option>
                            <option value="November">November</option>
                            <option value="Desember">Desember</option>
                            </select>  
                </div>
                <div class="input-field">
                <label for="tahun">Tahun Dibayar</label>
                    <select name="tahun_dibayar" size="1" id="tahun" required>
                    <option value="Pilih tahun" selected disabled>Pilih tahun</option>
                    <?php
                    for ($i=2000;$i<=date('Y');$i++)
                    {
                    echo "<option value=".$i.">".$i."</option>";
                    }
                    ?>
                    </select>
                </div>
                <div class="input-field">
                    <label>Jumlah Bayar (Jumlah yang harus dibayar adalah <b><?= number_format($kekurangan,2,',','.'); ?></b> )</label>
                    <input type="number" max="<?= $kekurangan; ?>" name="jumlah_bayar" required>
                </div>
            </div>
        </div>

        <div class="details ID">

                <div class="btnn">
            <button class="submitBtn">
                <span class="btnText">Submit</span>

            </button>
<br>            
            <div class="cancelBtn">
            <a href="entri.php">
                <span class="btnText">Kembali</span></a>
            </div>
           </div>

        </div> 
    </div>

   
        </div> 
    </div>
</form>
</div>

       



    </div>



<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

<!-- chart -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js" integrity="sha512-qKyIokLnyh6oSnWsc5h21uwMAQtljqMZZT17CIMXuCQNIfFSFF4tJdMOaJHL9fQdJUANid6OB6DRR0zdHrbWAw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/chart.js"></script>

<script>
          // menu toggle
          let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>

</body>
</html>