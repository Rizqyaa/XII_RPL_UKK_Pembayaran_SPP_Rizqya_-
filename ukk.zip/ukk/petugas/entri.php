<?php 
	session_start();
 
	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=error");
	}
 
if(!isset($_SESSION['username'])){
    header("location:../login.php");
}
include ('../conn.php');

	?>

 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="css/ind.css"> -->
    <link rel="stylesheet" href="css/entri.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css">

    <!-- <link rel="stylesheet" href="css/data.css"> -->


<!-- Style -->
<!-- <link rel="stylesheet" href="css/style.css"> -->
<style>
.box table
{
    width: 100%;
    border-collapse: collapse;
    /* margin-top: 10px; */
}
.box table thead td
{
    font-weight: 600;
}
.box .tabel table tr
{
    color: var(--black1);
    border-bottom: 1px solid rgba(0,0,0,0.1);
}
.box .tabel table tr:last-child
{
    border-bottom: none;
}
.box .tabel table tbody tr:hover
{
    background: var(--l1blue);
    color: var(--white);
}
.box .tabel table tr td
{
    padding: 10px;
}

.box .tabel table tr th:last-child,
.box .tabel table tr td:last-child
{
    text-align: start;
}
.box .tabel table tr th:nth-child(1),
.box .tabel table tr td:nth-child(1)
{
    text-align: start;
}


.box .tabel table tr th:nth-child(2),
.box .tabel table tr td:nth-child(2)
{
    text-align: center;
}

.box .tabel table tr th:nth-child(3),
.box .tabel table tr td:nth-child(3)
{
    text-align: start;
    white-space: nowrap;

}
.box .tabel table tr th:nth-child(4),
.box .tabel table tr td:nth-child(4)
{
    text-align: start;
}
.box .tabel table tr th:nth-child(5),
.box .tabel table tr td:nth-child(5)
{
    text-align: center;
    white-space: nowrap;
}
.box .tabel table tr th:nth-child(6),
.box .tabel table tr td:nth-child(6)
{
    text-align: start;
    white-space: nowrap;
}
.box .tabel table tr th:nth-child(7),
.box .tabel table tr td:nth-child(7)
{
    text-align: start;
    white-space: nowrap;

}
.box .tabel table tr th:nth-child(8),
.box .tabel table tr td:nth-child(8)
{
    text-align: start;
    white-space: nowrap;
}
.box .tabel table tr th:nth-child(9),
.box .tabel table tr td:nth-child(9)
{
    text-align: end;
    white-space: nowrap;
}
</style>
    <title>Petugas - Data Transaksi Pembayaran</title>
</head>
<body >
    <div class="container">
        <div class="nav active">
            <ol>
            <ul>
            <li>
                <a href="#">
                    <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                    <span class="title">spp</span>
                    <br>
                 </a>
               
                </li>
                <li class=" ">
                    <a href="index.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="entri.php">
                        <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                        <span class="title">Transaksi Pembayaran</span>
                    </a>
                </li>
                <li>
                    <a href="laporan.php">
                        <span class="icon"><ion-icon name="document"></ion-icon></span>
                        <span class="title">Laporan</span>
                    </a>
                </li>
                <li>
                    <a href="lout.php">
                        <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
                <!-- name -->
                      <span class="name">
                    <?php
                    echo "Welcome, "; echo $_SESSION['username'];
                    ?></span>
              
            </ul>
            </ol>
        </div>

        <!-- main -->

        <div class= "main active" >
            <div class="topbar">
                <!-- toggle -->
                <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
                </div>
                <!-- search -->
                <form action="" method="post">
                <div class="search">
                    <label for="">
                        <input type="text" name="keyword" placeholder="Search here">
                        <!-- <button type="submit" name="search">cri</button> -->
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>
                </form>
                <!-- user -->
                <div class="user">
                        <a href="index.php">
                            <div class="prof">
                            <img src="img/<?= $_SESSION['img'] ;?>" alt="">
                            </div>
                        </a>
                    </div>
                   
            </div>
            <!-- breadcrumb -->
            <nav aria-label="breadcrumb" class="crumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a> >  Data Transaksi Pembayaran</li>
            </ol>
            </nav>

            <!-- box -->
            <div class="graphbox">
       
                <div class="box">
    <div class="tabel">
        <div class="cardheader">
            <h2 class="">Data Pembayaran</h2>
        </div>
        <table class="table display" id="example">
          <thead>
            <tr> 
                <th scope="col" class="no">No</th>
                <th scope="col">NISN</th>
                <th scope="col">Nama Siswa</th>
                <th scope="col">Kelas</th>
                <th scope="col">Tahun</th>
                <th scope="col">Nominal</th>
                <th scope="col">Sudah Dibayar</th>
                <th scope="col">Kekurangan</th>
                <th scope="col" >Status</th>
                <th scope="col">History</th>
            </tr>
          </thead>
          <tbody>
            <?php
            // $query = $db->query('SELECT petugas.nama, pembayaran.idPembayaran, pembayaran.nisn , siswa.name, kelas.namaKelas, kelas.kompetensiKeahlian ,pembayaran.jumlah_bayar, pembayaran.tglBayar FROM (((pembayaran INNER JOIN petugas ON pembayaran.idPetugas = petugas.idPetugas) INNER JOIN siswa ON pembayaran.nisn = siswa.nisn ) INNER JOIN kelas ON siswa.idkls = kelas.idkls );')->fetchAll();
            $con = mysqli_connect('localhost','root','','ukp');
            $q ='SELECT * FROM siswa,spp,kelas WHERE siswa.idkls=kelas.idkls AND siswa.idSpp=spp.idSpp ORDER BY name ASC';
            $no=1;
            $query = mysqli_query($con, $q);
            foreach ($query as $data):
            $dataPembayaran = mysqli_query($con,"SELECT SUM(jumlah_bayar) as jumlah_bayar FROM pembayaran WHERE nisn='$data[nisn]'");
            $dataPembayaran = mysqli_fetch_array($dataPembayaran);
            $sdhbyr = $dataPembayaran['jumlah_bayar'];
            $kekurangan = $data['nominal']-$dataPembayaran['jumlah_bayar'];
            ?>

            <tr scope="row">
              
                <td><?php echo $no++; ?></td>
                <td><?= $data['nisn']?></td>
                <td><?= $data['name']?></td>           
                <td><?= $data['namaKelas']?> <?= $data['kompetensiKeahlian']?></td>           
                <td><?= $data['tahun']?></td>
                <td><?= number_format($data['nominal'],2,',','.'); ?> </td>    
                <td><?= number_format($sdhbyr,2,',','.'); ?></td>
                <td><?= number_format($kekurangan,2,',','.'); ?></td>
                <td>
                    <?php
                    if($kekurangan==0){
                        echo"<span class='badge' style='font-size:12px;padding:2px 4px;background:#2F58CD;color:white;border-radius:4px;white-space: nowrap;'>Sudah Lunas</span>";
                    }else{?>
                    <a href="fentri.php?nisn=<?= $data['nisn'] ?>&kekurangan=<?= $kekurangan?>" class="btn byr" style="background:#F7B633;white-space: nowrap;">Pilih & Bayar</a>
                <?php } ?>
                <!-- <a href="" class="btn-action edit"><ion-icon name="create-outline"></ion-icon></a> -->
              </td>
              <td>
                <a href="histo.php?nisn=<?= $data['nisn']; ?>" class="btn" style="background:#222;"><ion-icon name="file-tray-full-outline"></ion-icon></a>
                
              </td>      
           
            </tr>
            
            </td>
         
            <?php endforeach ?>
            
                </tbody>
            </table>
                </div>
                </div>

    </div>



<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

<!-- chart -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js" integrity="sha512-qKyIokLnyh6oSnWsc5h21uwMAQtljqMZZT17CIMXuCQNIfFSFF4tJdMOaJHL9fQdJUANid6OB6DRR0zdHrbWAw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/chart.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {
    $('#example').DataTable();
});
</script>
<script>
          // menu toggle
          let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>

</body>
</html>