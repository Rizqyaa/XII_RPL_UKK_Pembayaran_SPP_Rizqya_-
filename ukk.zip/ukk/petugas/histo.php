<?php 
	session_start();
 
	// cek apakah yg mengakses halaman ini sdh login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=error");
	}
 
if(!isset($_SESSION['username'])){
    header("location:../login.php");
}

	?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/histo.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css">

<!-- Style -->
<style>

.btn-action.delete
{
    position: relative;
    padding: 5px 10px;
    background: var(--red);
    text-decoration: none;
    color: var(--white);
    border-radius: 6px;
}
.btn-action.edit
{
    position: relative;
    padding: 5px 10px;
    background: var(--green);
    text-decoration: none;
    color: var(--white);
    border-radius: 6px;
}
  table
{
    width: 100%;
    border-collapse: collapse;
    /* margin-top: 10px; */
}
  table thead td
{
    font-weight: 600;
}
.tabel table tr
{
    color: var(--black1);
    border-bottom: 1px solid rgba(0,0,0,0.1);
}
.tabel table tr:last-child
{
    border-bottom: none;
}
.tabel table tbody tr:hover
{
    background: var(--l1blue);
    color: var(--white);
}
.tabel table tr td
{
    padding: 10px;
}

.tabel table tr th:last-child,
.tabel table tr td:last-child
{
    text-align: start;
}
.tabel table tr th:nth-child(1),
.tabel table tr td:nth-child(1)
{
    text-align: start;
}


.tabel table tr th:nth-child(2),
.tabel table tr td:nth-child(2)
{
    text-align: center;
}

.tabel table tr th:nth-child(3),
.tabel table tr td:nth-child(3)
{
    text-align: center;

}
.tabel table tr th:nth-child(4),
.tabel table tr td:nth-child(4)
{
    text-align: start;
}
.tabel table tr th:nth-child(5),
.tabel table tr td:nth-child(5)
{
    text-align: center;
    white-space: nowrap;

}
.tabel table tr th:nth-child(6),
.tabel table tr td:nth-child(6)
{
    text-align: start;
}
.tabel table tr th:nth-child(7),
.tabel table tr td:nth-child(7)
{
    text-align: start;
    white-space: nowrap;

}
.tabel table tr th:nth-child(8),
.tabel table tr td:nth-child(8)
{
    text-align: start;
    white-space: nowrap;

}
.tabel table tr th:nth-child(9),
.tabel table tr td:nth-child(9)
{
    text-align: start;
    white-space: nowrap;

}
</style>
    <title>Petugas - History </title>
</head>
<body >
    <div class="container">
        <div class="nav active">
            <ol>
            <ul>
            <li>
                <a href="#">
                    <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                    <span class="title">spp</span>
                    <br>
                 </a>
               
                </li>
                <li class="active">
                    <a href="index.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="entri.php">
                        <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                        <span class="title">Transaksi Pembayaran</span>
                    </a>
                </li>
                <li>
                    <a href="laporan.php">
                        <span class="icon"><ion-icon name="document"></ion-icon></span>
                        <span class="title">Laporan</span>
                    </a>
                </li>
                <li>
                    <a href="lout.php">
                        <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
                </li>
                <!-- name -->
                      <span class="name">
                    <?php
                    echo "Welcome, "; echo $_SESSION['username'];
                    ?></span>
               
               
            </ul>
            </ol>
        </div>

        <!-- main -->

        <div class= "main active" >
            <div class="topbar">
                <!-- toggle -->
                <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
                </div>
                <!-- search -->
                <form action="" method="post">
                <div class="search">
                    <label for="">
                        <input type="text" name="keyword" placeholder="Search here">
                        <!-- <button type="submit" name="search">cri</button> -->
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>
                </form>
                <!-- user -->
                    <div class="user">
                        <a href="index.php">
                            <div class="prof">
                            <img src="../img/<?= $_SESSION['img'] ;?>" alt="">
                            </div>
                        </a>
                    </div>
            </div>
            <!-- breadcrumb -->
            <nav aria-label="breadcrumb" class="crumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"> Dashboard</a> ><a href="entri.php"> Data Transaksi Pembayaran </a> > History </li>

            </ol>
            </nav>
            <!-- konten -->
            <div class="graphbox">
                <div class="tabel">
                <h2><a href="entri.php" class="btn" style="font-size:22px;background:#6B728E;"><ion-icon name="arrow-back-outline"></ion-icon></a>&nbsp; History Pembayaran</h2>
                    
                    <table class="table display" id="example">
                        <thead>
                        <tr>
                        <th>No</th>
                        <th>NISN</th>
                        <th>Kelas</th>
                        <th>Tahun SPP</th>
                        <th>Nominal</th>
                        <th>Sudah Dibayar</th>
                        <th>Tahun & Bulan Dibayar</th>
                        <th>Tanggal Bayar</th>
                        <th>Petugas</th>
                        <th>Hapus</th>

                        </tr>
                        <?php
                        include('../conn.php');
                        $nisn = $_GET['nisn'];
                        $no =1;
                        $query = $conn->query("SELECT * FROM pembayaran,siswa,kelas,spp,petugas WHERE pembayaran.nisn=siswa.nisn AND siswa.idkls=kelas.idkls AND pembayaran.idSpp=spp.idSpp AND pembayaran.idPetugas=petugas.idPetugas AND pembayaran.nisn='$nisn' ORDER BY tglBayar DESC")->fetchAll();
                        foreach ($query as $data):
                        
                        ?>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $data['nisn'] ?></td>
                                <td><?= $data['namaKelas'] ?> <?= $data['kompetensiKeahlian'] ?></td>
                                <td><?= $data['tahun'] ?></td>
                                <td>Rp. <?= number_format($data['nominal'],2,',','.'); ?> </td>
                                <td>Rp. <?= number_format($data['jumlah_bayar'],2,',','.'); ?> </td>
                                <td><?= $data['bulan_dibayar'] ?> | <?= $data['tahun_dibayar'] ?></td>
                                <td><?= $data['tglBayar'] ?></td>
                                <td><?= $data['nama'] ?></td>
                                <td>
                                <a href="delpem.php?idPembayaran=<?= $data['idPembayaran']; ?>" class="btn-delete btn-action delete"><ion-icon name="trash-outline"></ion-icon></a>
                
                                </td>   
                            </tr>
                        </tbody>
                        <?php endforeach ?>
                    </table>

                    </div>
            </div>

            </div>



    </div>



<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
<!-- sweet alert -->
<script src="../sweetalert/sweetalert2.min.js"></script>
<script src="../sweetalert/sweetalert2.all.min.js"></script>
<script src="../sweetalert/jquery-3.6.3.min.js"></script>
<script>
   $('.btn-delete').on('click', function(e){
    e.preventDefault();
    const href = $(this).attr('href')

    Swal.fire({
        title: 'Anda yakin?',
        text: "Data akan dihapus permanen!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus'
    }).then((result) => {
    if (result.value) {
        document.location.href = href;
    }
    })
   })
</script>
<!-- chart -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js" integrity="sha512-qKyIokLnyh6oSnWsc5h21uwMAQtljqMZZT17CIMXuCQNIfFSFF4tJdMOaJHL9fQdJUANid6OB6DRR0zdHrbWAw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/chart.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {
    $('#example').DataTable();
});
</script>
<script>
          // menu toggle
          let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>

</body>
</html>