<?php

if(isset($_SESSION['username'])){
    
  if ($_SESSION['level'] =='admin'){
    header("location:../admin/index.php");
  }
} 
require('../cek.php');
include ('../conn.php');
$query = $conn->query("SELECT * from petugas");
$data = $query->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="css/prof.css">
    <link rel="stylesheet" href="css/ind.css">
    <title>Petugas - Dashboard</title>

</head>
<body>
<div class="container">
        <div class="nav active">
            <ul>
                <li>
                <a href="#">
                    <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                    <span class="title">spp</span>
                    <br>
                 </a>
               
                </li>
                <li class="">
                    <a href="index.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="entri.php">
                        <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                        <span class="title">Transaksi Pembayaran</span>
                    </a>
                </li>
                <li>
                    <a href="laporan.php">
                        <span class="icon"><ion-icon name="document"></ion-icon></span>
                        <span class="title">Laporan</span>
                    </a>
                </li>
                <li>
                    <a href="lout.php">
                        <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
                      
              
            </ul>
          
        </div>

        <!-- main -->

        <div class="main active">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <!-- user -->
                <div class="user">
                <a href="profil.php">
                    <div class="prof">
                            <span class="name" style="float: left;"><?php echo "Hello, "; echo $_SESSION['username']; ?>!</span>&nbsp;
                            <img src="../img/<?= $_SESSION['img'] ;?>" alt="">
                            </div>
                        </a>
                    </div>
            </div>

            <!-- breadcrumb -->
            <nav aria-label="breadcrumb" class="crumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Dashboard</li><br>
            </ol>
            </nav>
          <!-- cards -->
          <div class="graphbox">
        <div class="kartu">
            <div class="imgbx">
                <img src="../img/<?= $_SESSION['img'] ;?>" alt="" width="100" height="100">
            </div>
        <div class="content">
            <div class="detail">
                <h2><?php echo $_SESSION['username']; ?><br><span>Petugas</span></h2>
            <div class="data">
                <h3>ID <br><span><?php echo $_SESSION['idPetugas']; ?></span></h3>
                <h3>Nama <br><span><?php echo $_SESSION['nama']; ?></span></h3>
                <a href="edprof.php?idPetugas=<?php echo $_SESSION['idPetugas']; ?>" class="btn">Edit Profil</a>

                </div>
            </div>
    </div>
        </div>
    </div>
  </div>

    </div>


        <!-- script -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

    <script>
        // menu toggle
        let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav.active');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>


</body>
</html>