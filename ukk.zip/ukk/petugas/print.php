<?php 
	session_start();
 
	// cek apakah yg mengakses halaman ini sdh login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=error");
	}
 
if(!isset($_SESSION['username'])){
    header("location:../login.php");
}

	?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/histo.css">

<!-- Style -->
<style>
    body
    {
        align-items: center;
        justify-content: center;
    }

@media print {
	* { -webkit-print-color-adjust: exact; }
	html { background: none; padding: 0; }
	body { box-shadow: none; margin: 0; }
	span:empty { display: none; }
	.add, .cut { display: none; }
}
@media only print{
.print {
	display: none;
}
.back {
	display: none;
}
}

    .invoice-box
    {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Poppins';
    }

    .invoice-box table
    {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }

    .invoice-box table td
    {
        padding: 5px;
        vertical-align: top;
    }

    .invoice-box table tr td:nth-child(2)
    {
        text-align: right;
    }

    .invoice-box table tr.top table td
    {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.info table td
    {
        padding-bottom: 40px;
    }

    .invoice-box table tr.heading td
    {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }

    .invoice-box table tr.detail td
    {
        border-bottom: 1px solid #eee;
    }

    .invoice-box table tr.item td
    {
        border-bottom: 1px solid #eee;
    }
@media only screen and (max-width:600px)
{
    .invoice-box table tr.top table td
    {
        width: 100%;
        display: block;
        text-align: center;
    }

    .invoice-box table tr.info table td
    {
        width: 100%;
        display: block;
        text-align: center;
    }

}
</style>
    <title>Petugas - Print </title>
</head>
<body >
<?php
            ?>
    <?php
        include ('../conn.php');

        $id = $_GET['idPembayaran'];
        include('../mys.php');
        $q ="SELECT * FROM pembayaran,siswa,kelas,spp,petugas WHERE pembayaran.nisn=siswa.nisn AND siswa.idkls=kelas.idkls AND pembayaran.idSpp=spp.idSpp AND pembayaran.idPetugas=petugas.idPetugas AND pembayaran.idPembayaran='$id' ORDER BY tglBayar DESC";
        $query = mysqli_query($con, $q);
        $no =1;
        foreach ($query as $data){
            $dataPembayaran = mysqli_query($con,"SELECT SUM(jumlah_bayar) as jumlah_bayar FROM pembayaran WHERE nisn='$data[nisn]'");
            $dataPembayaran = mysqli_fetch_array($dataPembayaran);
            $sdhbyr = $dataPembayaran['jumlah_bayar'];
            $kekurangan = $data['nominal']-$dataPembayaran['jumlah_bayar'];
    ?>
  <div class="invoice-box ">
  <!-- <span style="font-size:20px;background:#645CBB;"><button style="border:none;" class="btn print" onclick="window.print()"><ion-icon name="print"></ion-icon></button> -->
    <table cellpadding="0" cellspacing="0">
        <tr class="top">
            <td colspan="2">
                <table>
                    <tr>
                        <td>
                            <h4>Pembayaran SPP</h4>
                        </td>
                        <td>
                            Id Pembayaran : <span><?= $data['idPembayaran'] ?></span> <br>
                            Dibuat Tanggal : <span class="date"><?php echo date('d M Y')?></span> <br>
                            Yang Harus Dibayar : <span id="rupiah"><?= number_format($data['nominal'],2,',','.'); ?></span><br>
                        </td>

                    </tr>
                </table>
                <!-- end table -->
            </td>
        </tr>

        <tr class="info">
            <td colspan="2">
                <table>
                    <tr>
                        <td>
                            Petugas : <br>
                            <?= $data['nama'] ?> <br>
                        </td>

                        <td>
                            Nama Murid :  <br>
                            <?= $data['name'] ?> <br>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>

        <tr class="heading">
            <td>
                NISN
            </td>
            <td><?= $data['nisn'] ?></td>
        </tr>

        <tr class="detail">
            <td>Kelas</td>
            <td><?= $data['namaKelas'] ?> <?= $data['kompetensiKeahlian'] ?></td>
        </tr>

        <tr class="heading">
            <td>SPP</td>
            <td>Tahun ajaran : <?= $data['tahun'] ?> | <?= $data['bulan'] ?> </td>
        </tr>

        <tr class="item">
            <td>Bulan & Tahun Yang Dibayar</td>
            <td><?= $data['bulan_dibayar'] ?> | <?= $data['tahun_dibayar'] ?></td>
        </tr>

        <tr class="item">
            <td>Jumlah Bayar</td>
            <td><?= number_format($data['jumlah_bayar'],2,',','.'); ?> <?php
                    if($kekurangan==0){
                        echo"<span class='badge' style='font-size:12px;padding:2px 4px;background:#2F58CD;color:white;border-radius:4px;white-space: nowrap;cursor:pointer;'>Sudah Lunas</span>";
                    }else{
                        echo"<span class='badge' style='font-size:12px;padding:2px 4px;background:orange;color:white;border-radius:4px;white-space: nowrap;'>Belum Lunas</span>";
                        
                    }?>

            </td>
        </tr>
        <a href="laporan.php" class="btn back" style="font-size:22px;background:#6B728E;float:left;"><ion-icon style="font-size: 20px;" name="arrow-back-outline"></ion-icon></a>
        <div style="font-size:21px;background:#18122B;float:right;" class="btn print" onclick="window.print()"><ion-icon class="fs-2" name="print"></ion-icon></div>
    </table>

  </div>
  <?php } ?>



<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

<!-- chart -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js" integrity="sha512-qKyIokLnyh6oSnWsc5h21uwMAQtljqMZZT17CIMXuCQNIfFSFF4tJdMOaJHL9fQdJUANid6OB6DRR0zdHrbWAw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/chart.js"></script>
<script>
          // menu toggle
          let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>
<script type="text/javascript">
		
		var rupiah = document.getElementById('rupiah');
		rupiah.addEventListener('keyup', function(e){
			// tambahkan 'Rp.' pada saat form di ketik
			// gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
			rupiah.value = formatRupiah(this.value, 'Rp. ');
		});
 
		/* Fungsi formatRupiah */
		function formatRupiah(angka, prefix){
			var number_string = angka.replace(/[^,\d]/g, '').toString(),
			split   		= number_string.split(','),
			sisa     		= split[0].length % 3,
			rupiah     		= split[0].substr(0, sisa),
			ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);
 
			// tambahkan titik jika yang di input sudah menjadi angka ribuan
			if(ribuan){
				separator = sisa ? '.' : '';
				rupiah += separator + ribuan.join('.');
			}
 
			rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
			return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
		}
	</script>
</body>
</html>