<?php

session_start();

include ('conn.php');

$nisn=$_POST['nisn'];
$pass=$_POST['pass'];

$klas = $conn->query("SELECT * FROM kelas");
$kls=$klas->fetch();

$query = $conn->query("SELECT * FROM siswa WHERE nisn='$nisn' AND pass='$pass'");
$data=$query->fetch();
if($query->rowCount()>0){

        $_SESSION['name'] = $data['name'];
        $_SESSION['imge'] = $data['imge'];
        $_SESSION['idkls'] = $kls['idkls'];
        $_SESSION['namaKelas'] = $kls['namaKelas'];
        $_SESSION['kompetensiKeahlian'] = $kls['kompetensiKeahlian'];
        $_SESSION['nisn']=$_POST['nisn'];
        $_SESSION['pass']=$_POST['pass'];
        header("Location:user/index.php");
    } else{
        // echo"<script>alert('NISN Anda Tidak Terdaftar Didalam Data Siswa Atau Password Anda Salah');window.Locatin.assign('loginus.php');</script>";
        header("location:loginus.php?error=NISN atau Password tidak valid");
    }

?>


<!-- validasi -->
<!-- <?php

session_start();

$nisn = htmlentities(trim($_POST['nisn']));
$pw = htmlentities(trim($_POST['pass']));

if(empty($nisn)){
    $error .="NISN tidak valid! <br>";
   }

if(empty($pass)){

    $error .="password tidak valid!";
  }
if($error == ""){
$db = new PDO('mysql:host=localhost;dbname=ukp','root','');
$query = $db->query("SELECT * FROM login WHERE nisn='$nisn' AND pass='$pw'");
if($query){
    $_SESSION['nama']=$_POST['nama'];
    $_SESSION['pass']=$_POST['pass'];
    header('location:user/index.php');
 }
}else{
   header("location:loginus.php?error=$error");
}
?> -->