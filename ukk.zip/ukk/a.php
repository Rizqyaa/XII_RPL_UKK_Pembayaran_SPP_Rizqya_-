
<?php

session_start();

include('conn.php');

$usn = $_POST['username'];
$pass = $_POST['pwd'];

$query = $conn->query("SELECT * FROM petugas WHERE username='$usn' AND pwd='$pass'");
// var_dump($query->fetch());
// die();
$data = $query->fetch();

if($query->rowCount()> 0){
    // var_dump("berhasil");
    // die();
    if($data['level']=="admin"){
      
        $_SESSION['idPetugas'] = $data['idPetugas'];
        $_SESSION['img'] = $data['img'];
        $_SESSION['nama'] = $data['nama'];
        $_SESSION['username'] = $_POST['username'];
        $_SESSION['pwd'] = $_POST['pwd'];
        $_SESSION['level'] = "admin";
        header('location:admin/index.php');
    }else if($data['level']=="petugas"){
        
        $_SESSION['idPetugas'] = $data['idPetugas'];
        $_SESSION['img'] = $data['img'];
        $_SESSION['nama'] = $data['nama'];
        $_SESSION['username'] = $_POST['username'];
        $_SESSION['pwd'] = $_POST['pwd'];
        $_SESSION['level'] = "petugas";
        header('location:petugas/index.php');
    }
} 
else {
    header('location:login.php?error=Username atau Password tidak valid');
}
?>