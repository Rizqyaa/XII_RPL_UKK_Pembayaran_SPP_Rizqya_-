<?php
$con = mysqli_connect('localhost','root','','ukp');
?>