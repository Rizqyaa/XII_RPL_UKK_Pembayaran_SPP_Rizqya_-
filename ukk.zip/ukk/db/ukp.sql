-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2023 at 08:48 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ukp`
--

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `idkls` int(11) NOT NULL,
  `namaKelas` varchar(10) NOT NULL,
  `kompetensiKeahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`idkls`, `namaKelas`, `kompetensiKeahlian`) VALUES
(1012, '10', 'RPL2'),
(1024, '10', 'RPL1'),
(1025, '11', 'RPL1'),
(1026, '12', 'RPL1'),
(1027, '10', 'TKJ'),
(1028, '11', 'TKJ'),
(1029, '12', 'TKJ'),
(1030, '11', 'RPL2'),
(1031, '12', 'RPL2'),
(1032, '10', 'TKJ SAMSUNG'),
(1033, '11', 'TKJ SAMSUNG'),
(1034, '12', 'TKJ SAMSUNG');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` enum('admin','staff','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `status`) VALUES
(1, 'ra', '321', 'admin'),
(2, 'kyo', '111', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `idPembayaran` int(11) NOT NULL,
  `idPetugas` int(11) NOT NULL,
  `nisn` varchar(10) NOT NULL,
  `tglBayar` date NOT NULL,
  `bulan_dibayar` varchar(8) NOT NULL,
  `tahun_dibayar` varchar(4) NOT NULL,
  `idSpp` int(11) NOT NULL,
  `jumlah_bayar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`idPembayaran`, `idPetugas`, `nisn`, `tglBayar`, `bulan_dibayar`, `tahun_dibayar`, `idSpp`, `jumlah_bayar`) VALUES
(51, 3, '0954084', '2023-03-07', 'Februari', '2023', 101, 200000),
(59, 3, '032189', '2023-03-07', 'Februari', '2023', 101, 200000);

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `idPetugas` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `pwd` varchar(32) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `level` enum('admin','petugas') NOT NULL,
  `img` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`idPetugas`, `username`, `pwd`, `nama`, `level`, `img`) VALUES
(3, 'yuki', '111', 'mafuyu', 'admin', 'ab1.jpg'),
(4, 'k', '444', 'kanade', 'admin', 'ak1.png'),
(5, 'shen', 'a123', 'shenhe', 'petugas', 'chongyun.jpg'),
(6, 'toya', '555', 'aoyagi toya', 'petugas', 'toya.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `nisn` char(10) NOT NULL,
  `nis` char(8) NOT NULL,
  `name` varchar(50) NOT NULL,
  `jk` enum('Laki-laki','Perempuan') NOT NULL,
  `pass` varchar(50) NOT NULL,
  `imge` varchar(300) NOT NULL,
  `idkls` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `notelp` varchar(13) NOT NULL,
  `idSpp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`nisn`, `nis`, `name`, `jk`, `pass`, `imge`, `idkls`, `alamat`, `notelp`, `idSpp`) VALUES
('032189', '2020546', 'xinqiu', 'Laki-laki', '321', 'default.jpg', 1025, 'liyue', '089414654', 101),
('0954084', '2023913', 'hu tao', 'Perempuan', '321', 'hutao.jpg', 1025, 'liyue', '08362714', 101);

-- --------------------------------------------------------

--
-- Table structure for table `spp`
--

CREATE TABLE `spp` (
  `idSpp` int(11) NOT NULL,
  `tahun` varchar(11) NOT NULL,
  `bulan` enum('Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember') NOT NULL,
  `nominal` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `spp`
--

INSERT INTO `spp` (`idSpp`, `tahun`, `bulan`, `nominal`) VALUES
(101, '2020-2023', 'Juli', 200000),
(106, '2021-2024', 'Juli', 200000),
(111, '2022-2025', 'Juli', 300000),
(112, '2023-2026', 'Juli', 300000);

-- --------------------------------------------------------

--
-- Table structure for table `stat`
--

CREATE TABLE `stat` (
  `jum_siswa` int(11) NOT NULL,
  `jum_petugas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`idkls`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`idPembayaran`),
  ADD KEY `idPetugas` (`idPetugas`),
  ADD KEY `idSpp` (`idSpp`),
  ADD KEY `nisn` (`nisn`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`idPetugas`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`nisn`),
  ADD KEY `idSpp` (`idSpp`),
  ADD KEY `idkls` (`idkls`),
  ADD KEY `idSpp_2` (`idSpp`);

--
-- Indexes for table `spp`
--
ALTER TABLE `spp`
  ADD PRIMARY KEY (`idSpp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `idPembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`idSpp`) REFERENCES `siswa` (`idSpp`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pembayaran_ibfk_2` FOREIGN KEY (`idPetugas`) REFERENCES `petugas` (`idPetugas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pembayaran_ibfk_3` FOREIGN KEY (`nisn`) REFERENCES `siswa` (`nisn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `siswa`
--
ALTER TABLE `siswa`
  ADD CONSTRAINT `siswa_ibfk_1` FOREIGN KEY (`idkls`) REFERENCES `kelas` (`idkls`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `siswa_ibfk_2` FOREIGN KEY (`idSpp`) REFERENCES `spp` (`idSpp`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
