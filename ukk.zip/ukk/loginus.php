<?php  
 session_start();  
 if(isset($_SESSION["nisn"]))  
 {  
      header("location:user/index.php");  
 }  
 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link href="css/log.css" rel="stylesheet"> -->
    <link href="css/login.css" rel="stylesheet">
    <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Siswa - Login </title>
</head>
<body style="background: #dee2e6;">
<div class="content">

            <section>
            <!-- <img src="img/winter.jpg" class="bg" alt=""> -->
   <div class="wrapper">
                <?php if(isset($_GET['error'])) : ?>
                <div class="container-fluid" id="alert" >
                <div class="alert alert-danger text-center" style="width:100%;margin:auto;border-radius:20px;" role="alert">
                <a href="loginus.php" class="btn-close" type="button" style="float:right;"></a>
                    <span class="text"><?= $_GET['error'] ?></span>
                </div>
              </div>
            <?php endif ?>
       <h2 class="text-center">Login</h2>
        <form  action="u.php"  method="post" class="p-3 mt-3">
            <div class="input-data">
                <input type="text" name="nisn" id="userName" required>
                <div class="underline"></div>
                <label for=""><ion-icon class="fs-5" name="person"></ion-icon> NISN</label>
            </div>
            <br>
            <div class="input-data mt-4">
                <input type="password" name="pass" id="pwd"  required>
                <div class="underline"></div>
                <label for=""><ion-icon class="fs-5" name="lock"></ion-icon> Password</label>
            </div>
            <br>
            <button class="btn mt-5">Login</button>
        </form>
    </div>
    </div>
</section>
<!-- <script src="admin/js/show.js"></script> -->
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
</body>
</html>