<?php

$id = $_GET['idPembayaran'];

include('../conn.php');

$query = $conn->query("DELETE FROM pembayaran WHERE idPembayaran='$id'");
$data = $query->fetch();
if($data){
    echo "<script>alert('Maaf data tidak terhapus'); window.history.go(-1);</script>";

}else{
    echo "<script>window.history.go(-1);</script>";

}