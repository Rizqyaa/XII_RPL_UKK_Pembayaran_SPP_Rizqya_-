<?php 
session_start();

if(!isset($_SESSION['username'])){
    header("location:../login.php");
}
// $id = $data['idPetugas'];
include('../conn.php');

	?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/ind.css">

    <title>Admin - Dashboard</title>
</head>
<body >
    <div class="container">
        <div class="nav active">
            <ol>
            <ul>
                <li>
                    <a href="#">
                        <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                        <span class="title">Pembayaran SPP</span>
                        <br>
                    </a>
                </li>
                <li class="">
                    <a href="index.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="entri.php">
                        <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                        <span class="title">Transaksi Pembayaran</span>
                    </a>
                </li>
                <li>
                    <a href="laporan.php">
                        <span class="icon"><ion-icon name="documents-outline"></ion-icon></span>
                        <span class="title">Laporan</span>
                    </a>
                </li>
                <li>
                    <a href="profil.php">
                        <span class="icon"><ion-icon name="person-circle-outline"></ion-icon></span>
                        <span class="title">Account</span>
                    </a>
                </li>
                <li>
                    <a href="lout.php">
                        <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
                
            </ul>
        </ol>
    </div>
    
    <!-- main -->   
    
    <div class="main active" >
        <div class="topbar">
            <!-- toggle -->
            <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
            </div>
            <!-- user -->
            <div class="user">
                <a href="profil.php">
                    <div class="prof">
                            <span class="name" style="float: left;"><?php echo "Hello, "; echo $_SESSION['username']; ?>!</span>&nbsp;
                            <img src="../img/<?= $_SESSION['img'] ;?>" alt="">
                            </div>
                        </a>
                    </div>
            </div>
            <!-- breadcrumb -->
            <nav aria-label="breadcrumb" class="crumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Dashboard</li>
            </ol>
            </nav>

          <!-- cards -->
          <div class="cardBox">
              <a href="data/staff.php">
                <div class="card1">
                    <div class="">
                        <div class="judul">Petugas</div>
                        <div class="cardname"></div>
                    </div>
                    <div class="iconbx">
                    <ion-icon name="person-outline"></ion-icon>
                    </div>
                </div>
                </a>
                
                <a href="data/student.php" class="">
                <div class="card3">
                    <div class="">
                        <div class="judul">Murid</div>
                        <div class="cardname"></div>
                    </div>
                    <div class="iconbx">
                    <ion-icon name="id-card-outline"></ion-icon>
                    </div>
                </div> 
                </a>

                <a href="data/spp.php" class="">
                <div class="card2">
                    <div class="">
                        <div class="judul">Spp</div>
                        <div class="cardname"></div>
                    </div>
                    <div class="iconbx">
                    <ion-icon name="document-text-outline"></ion-icon>
                </div>
                </div>
                </a>


                <a href="data/class.php">
                <div class="card4">
                    <div class="">
                        <div class="judul">Kelas</div>
                        <div class="cardname"></div>
                    </div>
                    <div class="iconbx">
                    <ion-icon name="tablet-landscape-outline"></ion-icon>
                    </div>
                </div>
                </a>

            </div>

    </div>



<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

<!-- chart -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js" integrity="sha512-qKyIokLnyh6oSnWsc5h21uwMAQtljqMZZT17CIMXuCQNIfFSFF4tJdMOaJHL9fQdJUANid6OB6DRR0zdHrbWAw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/chart.js"></script>

<script>
          // menu toggle
          let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active');

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>

</body>
</html>