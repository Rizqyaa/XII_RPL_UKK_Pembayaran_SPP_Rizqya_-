<?php 
	session_start();
	// cek apakah yg mengakses halaman ini sdh login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=error");
	}
 
if(!isset($_SESSION['username'])){
    header("location:../login.php");
}

?>
 <?php
include_once('library.php');
// variabel
$periode = "";
$awaltgl = "";
$akhirtgl = "";
$tglawal = "";
$tglakhir = "";

if(isset($_POST['btnshow'])){
    $tglawal = isset($_POST['txtTglAwal']) ? $_POST['txtTglAwal'] : "01-".date('m-Y');
    $tglakhir = isset($_POST['txtTglAkhir']) ? $_POST['txtTglAkhir'] : date('d-m-Y');
    $periode = "WHERE A.tglBayar BETWEEN '".$tglawal."' AND  '".$tglakhir."' ";
}
else
{
    $awaltgl = "01-".date('m-Y');
    $akhirtgl = date('d-m-Y');

    $periode = "WHERE A.tglBayar BETWEEN '".$awaltgl."' AND  '".$akhirtgl."' ";

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/laporan.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css">

<!-- Style -->
<style>


</style>
    <title>Admin - Laporan </title>
</head>
<body >
    <div class="container">
        <div class="nav active">
            <ol>
            <ul>
                <li>
                    <a href="#">
                        <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                        <span class="title">Pembayaran SPP</span>
                        <br>
                    </a>
                </li>
                <li class="">
                    <a href="index.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="entri.php">
                        <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                        <span class="title">Transaksi Pembayaran</span>
                    </a>
                </li>
                <li>
                    <a href="laporan.php">
                        <span class="icon"><ion-icon name="documents-outline"></ion-icon></span>
                        <span class="title">Laporan</span>
                    </a>
                </li>
                <li>
                    <a href="profil.php">
                        <span class="icon"><ion-icon name="person-circle-outline"></ion-icon></span>
                        <span class="title">Account</span>
                    </a>
                </li>
                <li>
                    <a href="lout.php">
                        <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
            </ul>
            </ol>
        </div>

        <!-- main -->

        <div class="main active" >
            <div class="topbar">
                <!-- toggle -->
                <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
                </div>
                <!-- user -->
                    <div class="user">
                        <div class="prof">
                        <img src="../img/<?= $_SESSION['img'] ;?>" alt="">
                        </div>
                    </div>
            </div>
            <!-- breadcrumb -->
            <nav aria-label="breadcrumb" class="crumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"> Dashboard</a> > <a href="laporan.php"> Laporan</a> > Laporan Pembayaran </li>

            </ol>
            </nav>

            <!-- chart -->
            <div class="graphbox">
                <div class="tabel">
                    <h2> Laporan Pembayaran</h2>
                    <h4>Periode Tanggal <b><?php echo indonesiatgl($tglawal); ?></b> s/d <b><?php echo indonesiatgl($tglakhir); ?></b></h4>
                    <form action=" " method="post" target="_self">
                        <div class="date">
                            <div class="col start">
                                <input type="date" name="txtTglAwal" value="<?php echo $awaltgl; ?>" size="10" >
                            </div>&nbsp;&nbsp;&nbsp;
                            <div class="col last">
                                <input type="date" name="txtTglAkhir" value="<?php echo $akhirtgl; ?>" size="10" >
                            </div>&nbsp;&nbsp;&nbsp;
                            <div class="col button">
                                <input type="submit" name="btnshow" class="btn-success" value="Tampilkan" />
                            </div>
                          
                        </div>
                    <br><br>
                    <div class=""style="font-size:21px;float:left;" >
                                <a href="printreppay.php?awal=<?php echo $tglawal; ?>&akhir=<?php echo $tglakhir; ?>" target="_blank" alt="Edit Data" class="" ><div  class="btn-primary"><ion-icon class="fs-2" name="print"></ion-icon></div></a>
                    </div><br><br><br><br>
                    </form>
                    
                    <table class="table display" id="example">
                       <thead>
                        <tr>
                            <th scope="col" class="no">No</th>
                            <th scope="col">Petugas</th>
                            <th scope="col">NISN</th>
                            <th scope="col">Nama Siswa</th>
                            <th scope="col">Kelas</th>
                            <th scope="col">Tahun SPP</th>
                            <th scope="col">Bayar Di Bulan & Tahun </th>
                            <th scope="col">Tanggal Bayar</th>
                            <th scope="col">Status</th>
                            <th scope="col">Sudah Dibayar</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        
                        include('../mys.php');
                        // $q = "SELECT * FROM pembayaran,siswa,kelas,spp,petugas WHERE pembayaran.nisn=siswa.nisn AND siswa.idkls=kelas.idkls AND pembayaran.idSpp=spp.idSpp AND pembayaran.idPetugas=petugas.idPetugas ORDER BY tglBayar DESC";
                        $sql = "SELECT A.*, B.*, C.*, D.*, E.nama FROM pembayaran A, siswa B,kelas C ,spp D ,petugas E  $periode AND A.nisn=B.nisn AND B.idkls=C.idkls AND A.idSpp=D.idSpp AND A.idPetugas=E.idPetugas ORDER BY tglBayar DESC" ;
                        $myqry = mysqli_query($con, $sql);
                        // $query = mysqli_query($con, $q) ;
                        $no =1;
                        
                        foreach ($myqry as $data):
                            $dataPembayaran = mysqli_query($con,"SELECT SUM(jumlah_bayar) as jumlah_bayar FROM pembayaran WHERE nisn='$data[nisn]'");
                            $dataPembayaran = mysqli_fetch_array($dataPembayaran);
                            $sdhbyr = $dataPembayaran['jumlah_bayar'];
                            $kekurangan = $data['nominal']-$dataPembayaran['jumlah_bayar'];
                        ?>
                            <tr scope="row">
                                <td><?= $no++; ?></td>
                                <td><?= $data['nama']?></td>
                                <td><?= $data['nisn'] ?></td>
                                <td><?= $data['name'] ?></td>
                                <td><?= $data['namaKelas'] ?> <?= $data['kompetensiKeahlian'] ?></td>
                                <td><?= $data['tahun'] ?></td>
                                <td><?= $data['bulan_dibayar'] ?> | <?= $data['tahun_dibayar'] ?></td>
                                <td><?= $data['tglBayar'] ?></td>
                                <td>
                                    <?php
                                        if($kekurangan==0){
                                            echo"<span class='badge' style='font-size:12px;padding:2px 4px;background:#2F58CD;color:white;border-radius:4px;white-space: nowrap;'>Sudah Lunas</span>";
                                        }else{
                                            echo "<span class='badge' style='font-size:12px;padding:2px 4px;background:#F7B633;color:white;border-radius:4px;white-space: nowrap;'>Belum Lunas</span>";
                                        } ?>
                                    <!-- <a href="" class="btn-action edit"><ion-icon name="create-outline"></ion-icon></a> -->
                                </td> 
                                <td>Rp. <?= number_format($data['jumlah_bayar'],2,',','.'); ?> </td>
                            </tr>
                        <?php endforeach ?>
                        </tbody>
                    </table>
                </div>


            </div>



    </div>



<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

<!-- chart -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js" integrity="sha512-qKyIokLnyh6oSnWsc5h21uwMAQtljqMZZT17CIMXuCQNIfFSFF4tJdMOaJHL9fQdJUANid6OB6DRR0zdHrbWAw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/chart.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {
    $('#example').DataTable();
});
</script>
<script>
          // menu toggle
          let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>

</body>
</html>