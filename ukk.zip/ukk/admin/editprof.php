
<?php 

$id =$_POST['idPetugas'];
$username = $_POST['username'];
$pwd =$_POST['pwd'];
$nama =$_POST['nama'];
$img =$_POST['img'];

include('../conn.php');
  $query = $conn->query("UPDATE `petugas` SET `username`='$username',`nama`='$nama',`pwd`='$pwd',`nama`='$nama',`img`='$img' WHERE `idPetugas`='$id' ");

  if($query){
     header("Location:profil.php");
  }
  else{ 
    header("Location:edprof.php?error=$pesan_error");
  }

?>