
<?php 

$id =$_POST['idSpp'];
$thn = $_POST['tahun'];
$bln =$_POST['bulan'];
$nomi = $_POST['nominal'];

  include('../../conn.php');
  $query = $conn->query("UPDATE `spp` SET `idSpp`='$id',`tahun`='$thn',`bulan`='$bln',`nominal`='$nomi' WHERE `idSpp`='$id' ");

  if($query){
     header("Location:spp.php");
  }
  else{ 
    header("Location:feditspp.php?error=$pesan_error");
  }

?>