<?php
include ('../../conn.php');

require ('cek.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/data.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css">
    <!-- <link rel="stylesheet" href="css/add.css">  -->
    <!-- sweet alert -->
<link rel="stylesheet" href="../sweetalert/sweetalert2.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" id="theme-styles"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.2/dist/sweetalert2.min.css">
<!-- Style -->
<link rel="stylesheet" href="../css/style.css">
<style>

.details .tabel table tr th:last-child,
.details .tabel table tr td:last-child
{
    text-align: start;
}
.details .tabel table tr th:nth-child(1),
.details .tabel table tr td:nth-child(1)
{
    text-align: start;
}


.details .tabel table tr th:nth-child(2),
.details .tabel table tr td:nth-child(2)
{
    text-align: center;
}

.details .tabel table tr th:nth-child(3),
.details .tabel table tr td:nth-child(3)
{
    text-align: center;
}
.details .tabel table tr th:nth-child(4),
.details .tabel table tr td:nth-child(4)
{
    text-align: start;
}
.details .tabel table tr th:nth-child(5),
.details .tabel table tr td:nth-child(5)
{
    text-align: start;
}
</style>
    <title>Admin - Data Spp</title>
</head>
<body>
    <div class="container">
        <div class="nav active">
            <ol>
            <ul>
                <li>
                    <a href="#">
                        <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                        <span class="title">Pembayaran SPP</span>
                        <br>
                    </a>
                </li>
                <li class="">
                    <a href="../index.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="../entri.php">
                        <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                        <span class="title">Transaksi Pembayaran</span>
                    </a>
                </li>
                <li>
                    <a href="../laporan.php">
                        <span class="icon"><ion-icon name="documents-outline"></ion-icon></span>
                        <span class="title">Laporan</span>
                    </a>
                </li>
                <li>
                    <a href="../profil.php">
                        <span class="icon"><ion-icon name="person-circle-outline"></ion-icon></span>
                        <span class="title">Account</span>
                    </a>
                </li>
                </li>
                <li>
                    <a href="../lout.php">
                        <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
               
            </ul>
            </ol>
        </div>

        <!-- main -->

        <div class="main active">
            <div class="topbar">
                <!-- toggle -->
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <!-- search -->
                <div class="search">
                    <label for="">
                        <input type="text" placeholder="Search here">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>
                <!-- user -->
                    <div class="user">
                        <a href="../profil.php">
                            <div class="prof">
                            <img src="../../img/<?= $_SESSION['img'] ;?>" alt="">
                            </div>
                        </a>
                    </div>
            </div>

             <!-- breadcrumb -->
             <nav aria-label="breadcrumb" class="crumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index.php">Dashboard</a> > Data SPP</li>
            </ol>
            </nav>
         
    <div class="details">
            <div class="graphbox">
            <div class="box">
                <h1 class="title">Tambah Data SPP</h1>
        <form action="addsp.php" method="post">
            <div class="main-info">
                <div class="input-box">
                    <label for="idSpp">Id</label>
                    <input type="text" id="idSpp" name="idSpp" placeholder="Masukan Id" required>
                    
                </div>
                <div class="input-box">
                <label for="tahun">Tahun Ajaran</label>
                    <input type="text" name="tahun" required autocomplete="off" placeholder="Masukan Tahun Ajaran">

                </div>
                <div class="input-box">
                      
                <label for="bulan">Bulan</label>
                            <select name="bulan" size="1" id="bulan">
                            <option value="Pilih bulan" style="color:gray;" selected disabled>Pilih bulan</option>
                            <option value="Januari">Januari</option>
                            <option value="Februari">Februari</option>
                            <option value="Maret">Maret</option>
                            <option value="April">April</option>
                            <option value="Mei">Mei</option>
                            <option value="Juni">Juni</option>
                            <option value="Juli">Juli</option>
                            <option value="Agustus">Agustus</option>
                            <option value="September">September</option>
                            <option value="Oktober">Oktober</option>
                            <option value="November">November</option>
                            <option value="Desember">Desember</option>
                            </select>  
                </div>
        
                <div class="input-box">
                    <label for="nominal">Nominal</label>
                    <input type="text" id="nominal" name="nominal" placeholder="Masukan Nominal" required>
                    
                </div>
                  
               
            </div>
        <div class="submit-btn">
                <input type="submit" id="btn-submit" value="Submit">
            </div>
            <div class="cancel-btn">
                <a href="spp.php"><input type="button" value="Reset"></a>
            </div>
        </form>
                </div>
                </div>
          
                <div class="tabel">
                    <div class="cardheader">
                        <h1>Data SPP</h1>

                    </div>
                    <table class="table display" id="example">
          <thead>
            <tr> 
                <th scope="col" class="no">No</th>
                <th scope="col">Id</th>
                <th scope="col">Tahun</th>
                <th scope="col">Bulan</th>
                <th scope="col">Nominal</th>
                <th scope="col"></th>
                <th scope="col"></th>
                
            
            </tr>
          </thead>
          <tbody>
            <?php
            $query = $conn->query('select * from spp');
            $no=1;
            while ($data = $query->fetch()):?>
            <tr scope="row">
              
                <td><?php echo $no++; ?></td>
                <td><?= $data['idSpp']?></td>
                <td><?= $data['tahun']?></td>
                <td><?= $data['bulan']?></td>
                <td><?= $data['nominal']?></td>              
                <td>
                <a href="feditspp.php?idSpp=<?= $data['idSpp']; ?>" class="btn-action edit"><ion-icon name="create-outline"></ion-icon></a>
              </td>
              <td>
                <a href="delspp.php?idSpp=<?= $data['idSpp']; ?>" class="btn-delete btn-action delete"><ion-icon name="trash-outline"></ion-icon></a>
                
              </td>      
           
            </tr>
            
            </td>
         
            <?php endwhile ?>
            
                </tbody>
            </table>
                </div>
                <!-- right details -->
                <!-- <div class="chart">
                    <div class="cardheader">
                        <h2></h2>
                    </div>
                    <table>

                    </table>
                </div> -->

            </div>


        </div>
</div>
    </div>



<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
<!-- sweet alert --> 
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.2/dist/sweetalert2.all.min.js"></script>
<script src="../sweetalert/sweetalert2.min.js"></script>
<script src="../sweetalert/sweetalert2.all.min.js"></script>
<script src="../sweetalert/jquery-3.6.3.min.js"></script>
<script>
    $('#btn-submit').on('click', function(a) {
    a.stopImmediatePropagation();
    const href = $(this).attr('href')
    
    Swal.fire({
        icon: 'success',
        title: 'Berhasil!',
        text: 'Data Berhasil Disimpan!'
        })
   })

   $('.btn-delete').on('click', function(e){
    e.preventDefault();
    const href = $(this).attr('href')

    Swal.fire({
        title: 'Anda yakin?',
        text: "Data akan dihapus permanen!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus'
    }).then((result) => {
    if (result.value) {
        document.location.href = href;
    }
    })
   })
</script>
<!-- chart -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js" integrity="sha512-qKyIokLnyh6oSnWsc5h21uwMAQtljqMZZT17CIMXuCQNIfFSFF4tJdMOaJHL9fQdJUANid6OB6DRR0zdHrbWAw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/chart.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {
    $('#example').DataTable();
});
</script>
<script>
        // menu toggle
        let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>
</body>
</html>