<?php

$id = $_GET['idSpp'];

include('../../conn.php');
$query = $conn->query("DELETE FROM `spp` WHERE idSpp='$id'");

if($query){
    header("Location:spp.php?m-1");
 }