<?php

$id = $_GET['idSpp'];
include('../../conn.php');
$query = $conn->query("SELECT * from spp where idSpp='$id' ");
$data = $query->fetch();

?>
<?php require ('cek.php');?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/edit.css" rel="stylesheet">
    <title>Edit data SPP</title>

</head>
<body>
<div class="kontainer">
<header>Edit data SPP</header>

<form action="editspp.php" method="post">
<input type="hidden" name="idSpp" value="<?= $id ?>">
<div class="form first">
        <div class="details personal">
            <!-- <span class="title">Personal Details</span> -->

            <div class="fields">
            <div class="input-field">

                <label class="id" for="idSpp">Id</label>
                <input  disabled type="text" id="idSpp" name="idSpp" placeholder="Masukan Id" value="<?= $data['idSpp']?>" required>

                </div>

                <div class="input-field">
                <label for="tahun">Tahun</label>
                <input type="text" name="tahun"  value="<?= $data['tahun']?>" required autocomplete="off" placeholder="Masukan Tahun Ajaran">

                </div>

                <div class="input-field">
                    <label for="spp">SPP Bulan</label>
                            <select name="bulan" size="1" id="spp" value="<?= $data['bulan']?>" required>
                            <option value="Pilih bulan" style="color:gray;" selected disabled>Pilih bulan</option>
                            <option value="Januari" <?= $data['bulan'] == 'Januari' ? 'selected' : '' ?>>Januari</option>
                            <option value="Februari" <?= $data['bulan'] == 'Februari' ? 'selected' : '' ?>>Februari</option>
                            <option value="Maret" <?= $data['bulan'] == 'Maret' ? 'selected' : '' ?>>Maret</option>
                            <option value="April" <?= $data['bulan'] == 'April' ? 'selected' : '' ?>>April</option>
                            <option value="Mei" <?= $data['bulan'] == 'Mei' ? 'selected' : '' ?>>Mei</option>
                            <option value="Juni" <?= $data['bulan'] == 'Juni' ? 'selected' : '' ?>>Juni</option>
                            <option value="Juli" <?= $data['bulan'] == 'Juli' ? 'selected' : '' ?>>Juli</option>
                            <option value="Agustus" <?= $data['bulan'] == 'Agustus' ? 'selected' : '' ?>>Agustus</option>
                            <option value="September" <?= $data['bulan'] == 'September' ? 'selected' : '' ?>>September</option>
                            <option value="Oktober" <?= $data['bulan'] == 'Oktober' ? 'selected' : '' ?>>Oktober</option>
                            <option value="November" <?= $data['bulan'] == 'November' ? 'selected' : '' ?>>November</option>
                            <option value="Desember" <?= $data['bulan'] == 'Desember' ? 'selected' : '' ?>>Desember</option>
                            </select>  
                </div>

                <div class="input-field">
                <label for="nominal">Nominal</label>
                    <input type="text" id="nominal" name="nominal" placeholder="Masukan Nominal"  value="<?= $data['nominal']?>" required>
                </div>


                
            </div>
        </div>

        <div class="details ID">
          
                <div class="btnn">
            <button class="submitBtn">
                <span class="btnText">Submit</span>

            </button>
            <div class="cancelBtn">
            <a href="spp.php">
                <span class="btnText">Cancel</span></a>
            </div>
           </div>

        </div> 
    </div>

   
        </div> 
    </div>

</form>
</div>

</body>
</html>