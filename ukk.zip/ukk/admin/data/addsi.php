<?php

session_start();

include('../../conn.php');

$nisn = $_POST['nisn'];
$nis = $_POST['nis'];
$name = $_POST['name'];
$jk = $_POST['jk'];
$pass = $_POST['pass'];
// $img = "../../img/default.jpg";
$idk = $_POST['idkls'];   
$almt = $_POST['alamat'];
$no = $_POST['notelp'];
$ids = $_POST['idSpp'];


$query = $conn->query("INSERT INTO `siswa`(`nisn`, `nis`, `name`, `jk`, `pass`, `imge`, `idkls`, `alamat`, `notelp`, `idSpp`) VALUES ('$nisn','$nis','$name','$jk','$pass','default.jpg','$idk','$almt','$no','$ids')");
$data = $query->fetchAll();
if($query){
    header('location:student.php?m-1');
}else{
    echo"<script> alert('Maaf Data Tidak Tersimpan'); window.locatin.assign('student.php');</script>";
    header('location:faddsi.php?error=$pesan_error');
}