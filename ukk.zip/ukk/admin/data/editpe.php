
<?php 

$id =$_POST['idPetugas'];
$username = $_POST['username'];
$nama = $_POST['nama'];
$level = $_POST['level'];

include('../../conn.php');
  $query = $conn->query("UPDATE `petugas` SET `username`='$username',`nama`='$nama',`level`='$level' WHERE `idPetugas`='$id' ");

  if($query){
     header("Location:staff.php");
  }
  else{ 
    header("Location:faddp.php?error=$pesan_error");
  }

?>