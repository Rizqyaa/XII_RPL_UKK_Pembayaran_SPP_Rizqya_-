<?php 

$id =htmlentities( $_POST['idkls']);
$kelas =htmlentities(trim( $_POST['namaKelas']));
$jur =htmlentities( $_POST['kompetensiKeahlian']);     
 
$pesan_error = "gagal";

  include('../../conn.php');
  $query = $conn->query("insert into kelas values('$id','$kelas','$jur')");
  $data = $query->fetch();

  if($query){
     header("Location:class.php?m-1");
  }else{ // jika ada error
  header("Location:class.php?error=$pesan_error");
}