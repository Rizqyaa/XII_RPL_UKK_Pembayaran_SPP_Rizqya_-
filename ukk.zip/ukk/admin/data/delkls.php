<?php


include('../../conn.php');
$query = $conn->query("DELETE FROM `kelas` WHERE idkls='$id'");

$id = $_GET['idkls'];
if($query){
    header("Location:class.php");
 }