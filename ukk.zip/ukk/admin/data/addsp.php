<?php

session_start();

include('../../conn.php');

$id = $_POST['idSpp'];
$thn = $_POST['tahun'];
$bln = $_POST['bulan'];
$nomi =$_POST['nominal'];

$pesan_error = "Gagal menambahkan data SPP!";

$query = $conn->query("INSERT INTO `spp` VALUES ('$id','$thn', '$bln' ,'$nomi')");
$data = $query->fetch();
if($query){
     header("Location:spp.php?m-1");
}else{
  header("Location:spp.php?error=$pesan_error");

}

?>