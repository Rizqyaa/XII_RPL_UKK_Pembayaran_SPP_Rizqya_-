<?php require ('cek.php');?>
<?php
include('../../conn.php');

if(!isset($_SESSION['username'])){
    header("location:../../login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/add.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Tambah data siswa</title>
<style>
 

</style>
</head>
<body style="background: var(--d3blue);font-family: 'Poppins', sans-serif;">    
    <div class="kontainer">
<header>Tambah data siswa</header>

<form action="addsi.php" method="post">

    <div class="form first">
        <div class="details personal">
            <!-- <span class="title">Personal Details</span> -->

            <div class="fields">
                <div class="input-field">
                    <label for="nisn">Nisn</label>
                    <input type="text" id="nisn" name="nisn" placeholder="Masukan Nisn" required>
                    
                </div>

                <div class="input-field">
                    <label for="nis">Nis</label>
                    <input type="text" id="nis" name="nis" placeholder="Masukan Nis" required>

                </div>

                <div class="input-field">
                    <label for="nama">Nama</label>
                    <input type="text" id="name" name="name" placeholder="Masukan Nama" required>
                
                </div>

                <div class="input-field">
                    <label for="alamat">Alamat</label>
                    <input type="text" id="alamat" name="alamat" placeholder="Masukan alamat" required>
                </div>


                <div class="input-field">
                <label for="formFile" class="form-label">Jenis Kelamin</label>
                    <select name="jk" id="">
                            <option value="Pilih bulan" style="color:gray;" selected disabled>Pilih Jenis Kelamin</option>
                            <option value="Perempuan">Perempuan</option>
                            <option value="Laki-Laki">Laki-Laki</option>
                            </select>  
                </div>

                <div class="input-field">
                <label for="formFileLg" class="form-label">Kelas</label>
                    <select name="idkls" id="">
                <option value="" style="color:gray;" selected disabled>Pilih Kelas</option>

                <?php
                $query = $conn->query('SELECT * FROM kelas ORDER BY namaKelas ASC');

                foreach($query as $kls) :
                    
                ?>
                <option name="idkls" value="<?php echo $kls['idkls'] ?>"><?php echo $kls['namaKelas']; echo " - "; echo $kls['kompetensiKeahlian'] ?></option>
                <?php endforeach ?>
                 </select>
                </div>
            </div>

        </div>

        <div class="details ID">
            <!-- <span class="title">Identity Details</span> -->

            <div class="fields">
                
            <div class="input-field">
                <label for="formFileLg" class="form-label">SPP</label>
               <select name="idSpp" id="">
               <option value="" style="color:gray;" selected disabled>Pilih SPP</option>

                <?php
                $query = $conn->query('SELECT * FROM `spp` ORDER BY `idSpp` ASC');

                foreach($query as $spp) :
                    
                ?>

                <option name="idSpp" value="<?php echo $spp['idSpp']; ?>"> <?php echo $spp['tahun']; ?> | <?php echo $spp['nominal']; ?></option>

              
                <?php endforeach ?>
                 </select>
                </div>

                <div class="input-field">
                <label for="pass">Password</label>
                    <input type="password" id="pass" name="pass" placeholder="Masukan Password" required>
                </div>

                <div class="input-field">
                <label for="notelp">No Telp</label>
                    <input type="text" id="notelp" name="notelp" placeholder="Masukan No Telp" required>

                </div>

                
            </div>
                <div class="btnn">
            <button class="submitBtn">
                <span class="btnText" id="btn-submit">Submit</span>

            </button>
<br>            
            <div class="cancelBtn">
            <a href="student.php">
                <span class="btnText">Cancel</span></a>
            </div>
           </div>

        </div> 
    </div>

   
        </div> 
    </div>
</form>
</div>




</body>
</html>