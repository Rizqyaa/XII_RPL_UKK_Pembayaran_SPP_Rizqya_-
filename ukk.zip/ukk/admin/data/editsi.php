
<?php 

$nisn = $_POST['nisn'];
$nis = $_POST['nis'];
$name = $_POST['name'];
$pass = $_POST['pass'];
$idk = $_POST['idkls'];   
$almt = $_POST['alamat'];
$no = $_POST['notelp'];
$ids = $_POST['idSpp'];

include('../../conn.php');
$query = $conn->query("UPDATE `siswa` SET `name`='$name',`pass`='$pass',`idkls`='$idk',`alamat`='$almt',`notelp`='$no',`idSpp`='$ids' WHERE `nisn`='$nisn'");

  if($query){
     header("Location:student.php");
  }
  else{ 
    // echo"<script> alert('Maaf Data Tidak Tersimpan'); window.locatin.assign('student.php');</script>";
    header("Location:feditsi.php");
  }

?>