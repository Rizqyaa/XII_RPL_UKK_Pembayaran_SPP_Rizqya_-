<?php

$id = $_GET['idPetugas'];
include ('../../conn.php');
$query = $conn->query("SELECT * from petugas where idPetugas='$id' ");
$data = $query->fetch();

?>
<?php require ('cek.php');?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/add.css" rel="stylesheet">
    
    <title>Admin - Edit data petugas</title>

</head>
<body>
<div class="kontainer">
<header>Edit data petugas</header>

<form action="editpe.php" method="post">
<input type="hidden" name="idPetugas" value="<?= $id ?>">

    <div class="form first">
        <div class="details personal">

            <div class="fields">
                <div class="input-field">
                <label class="id"  for="idPetugas">Id</label>
                <input  disabled type="text" id="idPetugas" name="idPetugas" value="<?= $data['idPetugas']?>" required>
                </div>

                <div class="input-field">
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" value="<?= $data['nama']?>" required>
                </div>

                <div class="input-field">
                    
                <label for="username">username</label>
                <input type="text" id="username" name="username" value="<?= $data['username']?>" required>
                </div>
                
                <div class="input-field">
                <label for="level">Level</label>
                    <select name="level" id="level" value="<?= $data['level']?>"   >
                    <option value="admin" value="admin" <?= $data['level'] == 'admin' ? 'selected' : '' ?>>admin</option>
                    <option value="petugas" value="petugas" <?= $data['level'] == 'petugas' ? 'selected' : '' ?>>petugas</option>
                </select>
                </div>

                
            </div>
        </div>

        <div class="details ID">
          
                <div class="btnn">
            <button class="submitBtn">
                <span class="btnText">Submit</span>

            </button>
<br>            
            <div class="cancelBtn">
            <a href="staff.php">
                <span class="btnText">Cancel</span></a>
            </div>
           </div>

        </div> 
    </div>

   
        </div> 
    </div>
</form>
</div>

</body>
</html>