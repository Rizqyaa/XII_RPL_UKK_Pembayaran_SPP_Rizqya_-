<?php 
require ('cek.php');
include('../../conn.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/add.css" rel="stylesheet">
    
    <title>Tambah data petugas</title>

</head>
<body style="background: var(--d3blue);font-family: 'Poppins', sans-serif;">    
    <div class="kontainer">
<header>Tambah data petugas</header>

<form action="addpe.php" method="post">
<div class="form first">
        <div class="details personal">
            <!-- <span class="title">Personal Details</span> -->

            <div class="fields">
                <div class="input-field">
                    <label for="idPetugas">Id</label>
                    <input type="text" id="idPetugas" name="idPetugas" placeholder="Masukan Id" required>
                </div>

                <div class="input-field">
                    <label for="nama">Nama</label>
                    <input type="text" id="nama" name="nama" placeholder="Masukan Nama" required>
                </div>

                <div class="input-field">
                    
                    <label for="username">username</label>
                    <input type="text" id="username" name="username" placeholder="Masukan Username" required>
                </div>

                <div class="input-field">
                    <label for="pwd">Password</label>
                    <input type="password" id="pwd" name="pwd" placeholder="Masukan Password" required>

                </div>
<!--                 
                <div class="input-field">
                    <label for="formFile">Foto</label>
                    <input type="file" id="formFile" name="img" placeholder="Masukan img" required>
                </div> -->
                
                <div class="input-field" style="margin-right: 34%;">
                <label for="level">Level</label>
                    <select name="level" id="level">
                    <option selected><option>
                    <option value="admin">admin</option>
                    <option value="petugas">petugas</option>
                    </select>
                </div>

                
            </div>
        </div>

        <div class="details ID">
          
                <div class="btnn">
            <button class="submitBtn">
                <span class="btnText">Submit</span>

            </button>
<br>            
            <div class="cancelBtn">
            <a href="staff.php">
                <span class="btnText">Cancel</span></a>
            </div>
           </div>

        </div> 
    </div>

   
        </div> 
    </div>
</form>
</div>



</body>
</html>