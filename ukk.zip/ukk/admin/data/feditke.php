<?php

include('../../conn.php');
$id = $_GET['idkls'];
$query = $conn->query("SELECT * from kelas where idkls='$id' ");

$data = $query->fetch();

?>
<?php require ('cek.php');?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/edit.css" rel="stylesheet">
    <title>Edit data kelas</title>

</head>
<body>
<div class="kontainer">
<header>Edit data kelas</header>

<form action="editke.php" method="post">
<input type="hidden" name="idkls" value="<?= $id ?>">
<div class="form first">
        <div class="details personal">
            <!-- <span class="title">Personal Details</span> -->

            <div class="fields">

                <div class="input-field">
                <label class="id" for="idkls">Id</label>
                <input disabled type="text" id="idkls" name="idkls" placeholder="Masukan Id" value="<?= $data['idkls']?>"  required>

                </div>

                <div class="input-field">
                <label for="namaKelas">Kelas</label>
                    <select name="namaKelas" id="namaKelas" value="<?= $data['namaKelas']?>">
                    <option value="10" <?= $data['namaKelas'] == '10' ? 'selected' : '' ?>>10</option>
                    <option  value="11" <?= $data['namaKelas'] == '11' ? 'selected' : '' ?>>11</option>
                    <option  value="12" <?= $data['namaKelas'] == '12' ? 'selected' : '' ?>>12</option>
                    </select>
                </div>

                <div class="input-field">
                <label for="kompetensiKeahlian">Jurusan</label>
                    <input type="text" id="kompetensiKeahlian" name="kompetensiKeahlian" placeholder="Masukan Password" value="<?= $data['kompetensiKeahlian']?>" required>

                </div>


                
            </div>
        </div>

        <div class="details ID">
          
                <div class="btnn">
            <button class="submitBtn">
                <span class="btnText">Submit</span>

            </button>
            <div class="cancelBtn">
            <a href="class.php">
                <span class="btnText">Cancel</span></a>
            </div>
           </div>


    </div>

</form>
</div>

</body>
</html>