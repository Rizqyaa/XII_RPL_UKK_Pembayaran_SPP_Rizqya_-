<?php


include('../../conn.php');
$query = $conn->query("DELETE FROM `petugas` WHERE idPetugas='$id'");

$id = $_GET['idPetugas'];
if($query){
    header("Location:staff.php?m-1");
 }