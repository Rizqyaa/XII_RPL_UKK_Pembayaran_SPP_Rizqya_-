<?php


include('../../conn.php');
$query = $conn->query("DELETE FROM siswa WHERE nisn= '$nisn' ");

$nisn = $_GET['nisn'];
if($query){
    header("Location:student.php");
}else{
    echo"<script> alert('Maaf Data Tidak Terhapus'); window.locatin.assign('student.php');</script>";
}
 