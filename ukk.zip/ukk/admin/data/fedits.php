<?php

$nisn = $_GET['nisn'];
include('../../conn.php');
$query = $conn->query("SELECT * FROM siswa,spp,kelas WHERE siswa.idkls=kelas.idkls AND siswa.idSpp=spp.idSpp AND nisn='$nisn'");
$stun = $conn->query("SELECT * FROM siswa WHERE nisn='$nisn'");

$data = $query->fetch();

?>
<?php require ('cek.php');?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/add.css" rel="stylesheet">
    <title>Admin - Edit data siswa</title>

</head>
<body>
<div class="kontainer">
<header>Edit data siswa</header>

<form action="editsi.php" method="post">
<input type="hidden" name="nisn" value="<?= $nisn ?>">

    <div class="form first">
        <div class="details personal">

            <div class="fields">
                <div class="input-field">
                    <label class="id" for="nisn">Nisn</label>
                    <input disabled type="text" id="nisn" name="nisn" placeholder="Masukan Nisn"  value="<?= $data['nisn']?>"  readonly>
                    
                </div>

                <div class="input-field">
                    <label for="nis">Nis</label>
                    <input type="text" id="nis" name="nis" placeholder="Masukan Nis" value="<?= $data['nis']?>"  required>

                </div>

                <div class="input-field">
                    <label for="name">Nama</label>
                    <input type="text" id="name" name="name" placeholder="Masukan Nama" value="<?= $data['name']?>"  required>
                
                </div>

                <div class="input-field">
                    <label for="alamat">Alamat</label>
                    <input type="text" id="alamat" name="alamat" placeholder="Masukan alamat" value="<?= $data['alamat']?>"  required>
                </div>

                <div class="input-field">
                <label for="formFile" class="form-label">Jenis Kelamin</label>
                    <select name="jk" id="" value="<?= $data['jk']?>">
                        <option value="Perempuan" <?= $data['jk'] == 'Perempuan' ? 'selected' : '' ?>>Perempuan</option>
                        <option  value="Laki-Laki" <?= $data['jk'] == 'Laki-Laki' ? 'selected' : '' ?>>Laki-Laki</option>
                    </select>  
                </div>


                <div class="input-field">
                <label for="formFileLg" class="form-label">Kelas</label>
                    <select name="idkls" id="">
           
                    <option name="idkls" value="<?php echo $data['idkls'] ?>">
                    <?php echo $data['namaKelas']; echo " - "; echo $data['kompetensiKeahlian'] ?></option>

                <?php
                $query = $conn->query('SELECT * FROM kelas ORDER BY namaKelas ASC');

                foreach($query as $kls) :
                    
                ?>
                <option name="idkls" value="<?php echo $kls['idkls'] ?>"><?php echo $kls['namaKelas']; echo " - "; echo $kls['kompetensiKeahlian'] ?></option>
                <?php endforeach ?>
                 </select>
                </div>
            </div>
        </div>

        <div class="details ID">
            <!-- <span class="title">Identity Details</span> -->

            <div class="fields">

            <div class="input-field">
                <label for="formFileLg" class="form-label">SPP</label>
               <select name="idSpp" id="">
          
                <option value="<?php echo $data['idSpp']; ?>">
                <?php echo $data['idSpp'];?>  | <?php echo $data['tahun']; ?> | <?php echo $data['nominal']; ?>
                </option>
                <?php
                $query = $conn->query('SELECT * FROM spp ORDER BY `idSpp` ASC ');

                foreach($query as $spp) {
                    
                ?>
                
                <option name="idSpp" value="<?php echo $spp['idSpp']; ?>"><?php echo $spp['idSpp'];?>  | <?php echo $spp['tahun']; ?> | <?php echo $spp['nominal']; ?></option>
 
              
                <?php 
                }
                ?>
                 </select>
                </div>

                <div class="input-field">
                <label for="pass">Password</label>
                <input type="text" id="pass" name="pass" placeholder="Masukan Password"  value="<?= $data['pass']?>" required>

                </div>

                <div class="input-field">
                <label for="notelp">No Telp</label>
                <input type="text" id="notelp" name="notelp" placeholder="Masukan No Telp"  value="<?= $data['notelp']?>" required>

                </div>


            </div>
                <div class="btnn">
            <button class="submitBtn">
                <span class="btnText">Submit</span>

            </button>
<br>            
            <div class="cancelBtn">
            <a href="student.php">
                <span class="btnText">Cancel</span></a>
            </div>
           </div>

        </div> 
    </div>

   
        </div> 
    </div>
</form>
</div>

</body>
</html>