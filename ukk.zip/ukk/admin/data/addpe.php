<?php 

$id =htmlentities( $_POST['idPetugas']);
$username =htmlentities(trim( $_POST['username']));
$pwd =htmlentities( $_POST['pwd']);
$nama =htmlentities( $_POST['nama']);
$level = $_POST['level'];
$img = "default.jpg";

$pesan_error = "";

if(empty($id)){
  $pesan_error .= "Id tidak boleh kosong";
}
if(empty($username)){
  $pesan_error .= "Username tidak boleh kosong";
}
if(empty($pwd)){
  $pesan_error .= "Password tidak boleh kosong";
}
if(empty($nama)){
  $pesan_error .= "Nama tidak boleh kosong";
}
if(empty($level)){
  $pesan_error .= "Level tidak boleh kosong";
}

if($pesan_error == ""){ 
  include('../../conn.php');
  $query = $conn->query("insert into petugas values('$id','$username','$pwd','$nama' ,'$level','$img')");

  if($query){
     header("Location:staff.php");
  }

}else{ // jika ada error
  header("Location:faddp.php?error=$pesan_error");
}