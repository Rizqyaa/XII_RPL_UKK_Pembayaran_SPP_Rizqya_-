
<?php 

$id =$_POST['idkls'];
$nama = $_POST['namaKelas'];
$jur =$_POST['kompetensiKeahlian'];

  include('../../conn.php');
  $query = $conn->query("UPDATE `kelas` SET `idkls`='$id',`namaKelas`='$nama',`kompetensiKeahlian`='$jur' WHERE `idkls`='$id' ");

  if($query){
     header("Location:class.php");
  }


?>