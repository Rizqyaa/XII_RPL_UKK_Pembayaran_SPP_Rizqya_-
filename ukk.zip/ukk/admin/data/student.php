<?php
include ('../../conn.php');
require ('cek.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/data.css">
    <link rel="stylesheet" href="css/ind.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css">
<title>Admin - Data Murid</title>

<style>
    
.details .tabel table tr th:last-child,
.details .tabel table tr td:last-child
{
    text-align: start;
}
.details .tabel table tr th:nth-child(1),
.details .tabel table tr td:nth-child(1)
{
    text-align: start;
}


.details .tabel table tr th:nth-child(2),
.details .tabel table tr td:nth-child(2)
{
    text-align: center;
}

.details .tabel table tr td:nth-child(3)
{
    text-align: start;
}
.details .tabel table tr th:nth-child(3)
{
    text-align: center;
}
.details .tabel table tr th:nth-child(4),
.details .tabel table tr td:nth-child(4)
{
    text-align: start;
}
.details .tabel table tr th:nth-child(5),
.details .tabel table tr td:nth-child(5)
{
    text-align: start;
    white-space: nowrap;
}
.details .tabel table tr th:nth-child(6),
.details .tabel table tr td:nth-child(6)
{
    text-align: start;
}
.details .tabel table tr th:nth-child(7),
.details .tabel table tr td:nth-child(7)
{
    text-align: start;
}
.details .tabel table tr th:nth-child(8)
{
    text-align: center;
}
.details .tabel table tr td:nth-child(8)
{
    text-align: start;

}
.details .tabel table tr th:nth-child(9),
.details .tabel table tr td:nth-child(9)
{
    text-align: start;
}
</style>

</head>
<body>
    <div class="container">
        <div class="nav active">
            <ol>
            <ul>
                <li>
                    <a href="#">
                        <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                        <span class="title">Pembayaran SPP</span>
                        <br>
                    </a>
                </li>
                <li class="">
                    <a href="../index.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="../entri.php">
                        <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                        <span class="title">Transaksi Pembayaran</span>
                    </a>
                </li>
                <li>
                    <a href="../laporan.php">
                        <span class="icon"><ion-icon name="documents-outline"></ion-icon></span>
                        <span class="title">Laporan</span>
                    </a>
                </li>
                <li>
                    <a href="../profil.php">
                        <span class="icon"><ion-icon name="person-circle-outline"></ion-icon></span>
                        <span class="title">Account</span>
                    </a>
                </li>
                <li>
                    <a href="../lout.php">
                        <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
               
            </ul>
            </ol>
        </div>

        <!-- main -->

        <div class="main active">
            <div class="topbar">
                <!-- toggle -->
                <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>

                </div>
                <!-- search -->
                <div class="search">
                    <label for="">
                        <input type="text" placeholder="Search here">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>
                <!-- user -->
                    <div class="user">
                        <a href="../profil.php">
                            <div class="prof">
                            <img src="../../img/<?= $_SESSION['img'] ;?>" alt="">
                            </div>
                        </a>
                    </div>
            </div>

             <!-- breadcrumb -->
             <nav aria-label="breadcrumb" class="crumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../index.php">Dashboard</a> > Data Murid</li>
            </ol>
            </nav>
         


            <div class="details">
            <!-- detail list -->
                <div class="tabel">
                    <div class="cardheader">
                        <h1>Data Murid</h1>
                        <!-- <a href="#" class="btn"> view all</a> -->
                        <a href="faddsi.php" class="btn-add"> <ion-icon name="add"></ion-icon></a>
                    </div>
                    <table class="table display" id="example">
          <thead>
            <tr>  

              <th scope="col" class="no">No</th>
              <th scope="col">Nisn</th>
              <th scope="col">Nis</th>
              <th scope="col">Nama</th>
              <th scope="col">Jenis Kelamin</th>
              <th scope="col">Kelas</th>
              <!-- <th scope="col">Username</th>
              <th scope="col">Password</th> -->
              <th scope="col">Alamat</th>
              <!-- <th scope="col">Foto</th> -->
              <!-- <th scope="col">email</th> -->
              <th scope="col">No telp</th>
              <th scope="col">SPP</th>
              <th scope="col">Edit</th>
              <th scope="col">Delete </th>
            
            </tr>
          </thead>
          <tbody>
            <?php
              $query = $conn->query('SELECT * FROM siswa,spp,kelas WHERE siswa.idkls=kelas.idkls AND siswa.idSpp=spp.idSpp ORDER BY name ASC');
              $no=1;
            foreach ($query as $murid):?>
            <tr scope="row">
              
            <td><?php echo $no;$no++; ?></td>
              <td><?= $murid['nisn']?></td>
              <td><?= $murid['nis']?></td>
              <td><?= $murid['name']?></td>
              <td><?= $murid['jk']?></td>
              <td><?= $murid['namaKelas']?>  <?= $murid['kompetensiKeahlian']?></td>
              <!-- <td><?= $murid['usname']?></td>
              <td><?= $murid['pass']?></td> -->
              <td><small class="d-block"><?= $murid['alamat']?></small></td>
              <!-- <td><img src="../../img/<?= $murid['img']; ?>" width="90" height="90"/></td> -->
              <!-- <td><?= $murid['email']?></td> -->
              <td><?= $murid['notelp']?></td>
              <td><?= $murid['tahun']?> | <?= $murid['nominal']?> </td>
              
              <td>
                <a href="fedits.php?nisn=<?= $murid['nisn']; ?>" class="btn-action edit"><ion-icon name="create-outline"></ion-icon></a>
              </td>
              <td>
                <a  href="delsiswa.php?nisn=<?= $murid['nisn']; ?>" class="btn-delete btn-action delete"><ion-icon name="trash-outline"></ion-icon></a>
              </td>

          </tr>

            <?php endforeach ?>
            
          </tbody>
        </table>
                </div>
                <!-- right details -->
                <!-- <div class="chart">
                    <div class="cardheader">
                        <h2></h2>
                    </div>
                    <table>

                    </table>
                </div> -->

            </div>


        </div>
    </div>



<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
<!-- sweet alert -->
<script src="../sweetalert/sweetalert2.min.js"></script>
<script src="../sweetalert/sweetalert2.all.min.js"></script>
<script src="../sweetalert/jquery-3.6.3.min.js"></script>
<script>
    $('#btn-submit').on('click', function(a) {
    a.stopImmediatePropagation();
    const href = $(this).attr('href')
    
    Swal.fire({
        icon: 'success',
        title: 'Berhasil!',
        text: 'Data Berhasil Disimpan!'
        })
   })

   $('.btn-delete').on('click', function(e){
    e.preventDefault();
    const href = $(this).attr('href')

    Swal.fire({
        title: 'Anda yakin?',
        text: "Data akan dihapus permanen!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Hapus'
    }).then((result) => {
    if (result.value) {
        document.location.href = href;
    }
    })
   })
</script>
<!-- chart -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js" integrity="sha512-qKyIokLnyh6oSnWsc5h21uwMAQtljqMZZT17CIMXuCQNIfFSFF4tJdMOaJHL9fQdJUANid6OB6DRR0zdHrbWAw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="js/chart.js"></script>
<!-- data tables -->
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {
    $('#example').DataTable();
});
</script>
<!--  -->

<script>
        // menu toggle
        let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // add hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>

</body>
</html>