<?php

include ('../conn.php');
$query = $conn->query("SELECT * from petugas");
$data = $query->fetch();

?>

<?php require ('cek.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/ind.css">
    <link rel="stylesheet" href="css/prof.css">
<!-- Style -->
<!-- <link rel="stylesheet" href="css/style.css"> -->

    <title>Admin - Profil</title>
    <style>
        
    </style>
</head>
<body>
<div class="container">
        <div class="nav active">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                        <span class="title">Pembayaran SPP</span>
                        <br>
                    </a>
                </li>
                <li class="active">
                    <a href="index.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="entri.php">
                        <span class="icon"><ion-icon name="card-outline"></ion-icon></span>
                        <span class="title">Transaksi Pembayaran</span>
                    </a>
                </li>
                <li>
                    <a href="laporan.php">
                        <span class="icon"><ion-icon name="documents-outline"></ion-icon></span>
                        <span class="title">Laporan</span>
                    </a>
                </li>
                <li>
                    <a href="profil.php">
                        <span class="icon"><ion-icon name="person-circle-outline"></ion-icon></span>
                        <span class="title">Account</span>
                    </a>
                </li>
                <li>
                    <a href="lout.php">
                        <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
               
            </ul>
          
        </div>

        <!-- main -->
<div class="main active">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <!-- user -->
                     <div class="user">
                        <div class="prof">
                        <img src="../img/<?= $_SESSION['img'] ;?>" alt="">
                        </div>
                    </div>
            </div>
            <!-- breadcrumb -->
            <nav aria-label="breadcrumb" class="crumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Profil</li>
                </ol>
            </nav><br> 
          <!-- cards -->
          <div class="graphbox">
    <div class="kartu">
        <div class="imgbx">
            <img src="../img/<?= $_SESSION['img'] ;?>" alt="" width="100" height="100">
        </div>
        <div class="content">
            <div class="details">
                <h2><?php echo $_SESSION['username']; ?><br><span>Admin</span></h2>
            <div class="data">
                <h3>ID <br><span><?php echo $_SESSION['idPetugas']; ?></span></h3>
                <!-- <h3>Password <br><span><?php echo $_SESSION['pwd']; ?></span></h3> -->
                <h3>Nama <br><span><?php echo $_SESSION['nama']; ?></span></h3>
                <a href="edprof.php?idPetugas=<?php echo $_SESSION['idPetugas']; ?>" class="btn">Edit Profil</a>
                </div>
            </div>
    </div>
        
                </div>

    </div>
  </div>
                </div>
            </div>

            </div>

            
        </div>
    </div>


    
<!-- icon -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

     <!-- script -->
     <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

    <script>
        // menu toggle
        let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>
</body>
</html>