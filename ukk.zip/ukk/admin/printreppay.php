<?php 
	session_start();
 
	// cek apakah yg mengakses halaman ini sdh login
	if($_SESSION['level']==""){
		header("location:index.php?pesan=error");
	}
 
if(!isset($_SESSION['username'])){
    header("location:../login.php");
} 
include_once("library.php");
$awal = $_GET['awal'];
$tawal=indonesiatgl($awal);

$akhir = $_GET['akhir'];
$takhir=indonesiatgl($akhir);

    $tglawal = isset($_POST['awal']) ? $_POST['awal'] : "01-".date('m-Y');
    $tglakhir = isset($_POST['akhir']) ? $_POST['akhir'] : date('d-m-Y');
    $periode = "WHERE A.tglBayar BETWEEN '$awal' AND  '$akhir' ";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/laporan.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <!-- Style -->
    <style>
    body {
        margin: 20px;
    }
    @import url('https://fonts.googleapis.com/css2?family=Kulim+Park:wght@600;700&family=Lexend+Exa:wght@400;500;600;700;800&family=Montserrat:wght@400;500;600;700;800&family=Sulphur+Point:wght@700&display=swap');

    @media print {
        * {
            -webkit-print-color-adjust: exact;
        }

        html {
            background: none;
            padding: 0;
        }

        body {
            box-shadow: none;
            margin: 0;
        }

        span:empty {
            display: none;
        }

        .add,
        .cut {
            display: none;
        }
    }

    @media only print {
        .print {
            display: none;
        }

        .back {
            display: none;
        }
    }
    </style>
    <title>Admin - Print Laporan Pembayaran </title>
</head>

<body onload="print()">
    <div class=" ">
        <?php if (!empty($tglawal)) {?>
        <center><h2> LAPORAN PEMBAYARAN</h2>
        <h4>Periode Tanggal <b><?php echo indonesiatgl($awal); ?></b> s/d <b><?php echo indonesiatgl($akhir); ?></b>
        </h4></center>

        <table>
        <?php
        include('../mys.php');
        $nm = $_SESSION['nama'];
        $q ="SELECT * FROM petugas where nama='$nm'";
        $query = mysqli_query($con, $q);
        foreach ($query as $data){
        ?>
                    <tr>
                        <td>
                            Dicetak Oleh: <span><?= $data['nama'] ?></span> <br>
                            Tanggal Cetak: <span><?php date_default_timezone_set('Asia/Jakarta');$date = date('d F Y h:i:s A');echo $date;?></span> <br>
                            <!-- Yang Harus Dibayar : <span id="rupiah"><?= number_format($data['nominal'],2,',','.'); ?></span><br> -->
                        </td>
                    </tr>
                </table>
                <?php } ?>
        <hr>
        <?php } else {  ?>
       <center><h2 style="font-family: 'Montserrat';font-weight:700;">LAPORAN PEMBAYARAN</h2></center> 
        <?php } ?>
        <table class="table display" id="example">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Petugas</th>
                    <th scope="col">NISN</th>
                    <th scope="col"style="white-space:nowrap;" >Nama Siswa</th>
                    <th scope="col">Kelas</th>
                    <th scope="col" style="white-space:nowrap;" >Tahun SPP</th>
                    <th scope="col" style="white-space:nowrap;">Bayar Di Bulan & Tahun</th>
                    <th scope="col" style="white-space:nowrap;">Tanggal Bayar</th>
                    <th scope="col">Status</th>
                    <th scope="col">Sudah Dibayar</th>
                </tr>
            </thead>
            <tbody>
                <?php
                        
                        include('../mys.php');
                        // $q = "SELECT * FROM pembayaran,siswa,kelas,spp,petugas WHERE pembayaran.nisn=siswa.nisn AND siswa.idkls=kelas.idkls AND pembayaran.idSpp=spp.idSpp AND pembayaran.idPetugas=petugas.idPetugas ORDER BY tglBayar DESC";
                        $sql = "SELECT A.*, B.*, C.*, D.*, E.nama FROM pembayaran A, siswa B,kelas C ,spp D ,petugas E  $periode AND A.nisn=B.nisn AND B.idkls=C.idkls AND A.idSpp=D.idSpp AND A.idPetugas=E.idPetugas ORDER BY tglBayar DESC" ;
                        $myqry = mysqli_query($con, $sql);
                        // $query = mysqli_query($con, $q) ;
                        $no =1;
                        $jmlhbyr=0;
                        foreach ($myqry as $data):
                            $dataPembayaran = mysqli_query($con,"SELECT SUM(jumlah_bayar) as jumlah_bayar FROM pembayaran WHERE nisn='$data[nisn]'");
                            $dataPembayaran = mysqli_fetch_array($dataPembayaran);
                            $sdhbyr = $dataPembayaran['jumlah_bayar'];
                            $kekurangan = $data['nominal']-$dataPembayaran['jumlah_bayar'];
                            $jmlhbyr+=$data['jumlah_bayar'];
                        ?>
                <tr scope="row">
                    <td><?= $no++; ?></td>
                    <td><?= $data['nama']?></td>
                    <td><?= $data['nisn'] ?></td>
                    <td ><?= $data['name'] ?></td>
                    <td><?= $data['namaKelas'] ?> <?= $data['kompetensiKeahlian'] ?></td>
                    <td><?= $data['tahun'] ?></td>
                    <td><?= $data['bulan_dibayar'] ?> | <?= $data['tahun_dibayar'] ?></td>
                    <td><?= $data['tglBayar'] ?></td>
                    <td>
                        <?php
                                        if($kekurangan==0){
                                            echo"<span class='badge' style='font-size:12px;padding:2px 4px;background:#2F58CD;color:white;border-radius:4px;white-space: nowrap;'>Sudah Lunas</span>";
                                        }else{
                                            echo "<span class='badge' style='font-size:12px;padding:2px 4px;background:#F7B633;color:white;border-radius:4px;white-space: nowrap;'>Belum Lunas</span>";
                                        } ?>
                    </td>
                    <td>Rp. <?= number_format($data['jumlah_bayar'],2,',','.'); ?> </td>
                </tr>
                <?php endforeach ?>
            </tbody>
            <tr scope="row">
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th style="white-space:nowrap;"><strong>Total</strong></th>
                <th style="background: whitesmoke;white-space:nowrap;" align="right"><strong>Rp.
                        <?php echo number_format($jmlhbyr,2,',','.'); ?>,-</strong></th>
            </tr>
        </table>

    </div>



    <!-- icon -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>

    <!-- chart -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.2.0/chart.min.js"
        integrity="sha512-qKyIokLnyh6oSnWsc5h21uwMAQtljqMZZT17CIMXuCQNIfFSFF4tJdMOaJHL9fQdJUANid6OB6DRR0zdHrbWAw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="js/chart.js"></script>
    <script>
    // menu toggle
    let toggle = document.querySelector('.toggle');
    let nav = document.querySelector('.nav');
    let main = document.querySelector('.main');

    toggle.onclick = function() {
        nav.classList.toggle('active');
        main.classList.toggle('active')

    }
    // hovered class in selected list item
    let list = document.querySelectorAll('.nav li');

    function activeLink() {
        list.forEach((item) =>
            item.classList.remove('hovered'));
        this.classList.add('hovered');
    }
    list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>
</body>

</html>