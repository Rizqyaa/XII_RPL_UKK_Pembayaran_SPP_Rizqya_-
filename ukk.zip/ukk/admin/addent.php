<?php

session_start();

include('../conn.php');

$idpt = $_SESSION['idPetugas'];

$nisn = $_POST['nisn'];
$tgl = $_POST['tglBayar'];
$bln = $_POST['bulan_dibayar'];
$thn = $_POST['tahun_dibayar'];
$ids = $_POST['idSpp'];
$jmlh = $_POST['jumlah_bayar'];

$query = $conn->query("INSERT INTO `pembayaran`(`idPembayaran`, `idPetugas`, `nisn`, `tglBayar`, `bulan_dibayar`, `tahun_dibayar`, `idSpp`, `jumlah_bayar`) VALUES ('','$idpt','$nisn','$tgl','$bln','$thn','$ids','$jmlh')");
$data = $query->fetch();
if($query){
    header('location:entri.php');
    echo "<script>alert('Berhasil Melakukan Pembayaran!') window.location.assign('fentri.php')</script>";
}else{
    echo "<script>alert('Gagal Melakukan Pembayaran!') window.location.assign('fentri.php')</script>";
}