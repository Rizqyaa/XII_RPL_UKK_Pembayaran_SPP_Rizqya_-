<?php
$id = $_GET['idPetugas'];
include ('../conn.php');
$query = $conn->query("SELECT * from petugas where idPetugas='$id' ");
$data = $query->fetch();

?>

<?php require ('cek.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/editprof.css">
    <title>Admin - Edit Profil</title>
</head>
<body>
<div class="kontainer">
    <header>Edit Profil</header>

<form action="editprof.php" method="post">
<input type="hidden" name="idPetugas" value="<?= $id ?>">

    <div class="form first">
        <div class="detail personal">

            <div class="fields">
                <div class="input-field">
                <label class="id"  for="idPetugas">Id</label>
                <input  disabled type="text" id="idPetugas" name="idPetugas" value="<?= $data['idPetugas']?>" required>
                </div>

                <div class="input-field">
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" value="<?= $_SESSION['nama']?>" required>
                </div>

                <div class="input-field">
                <label for="username">username</label>
                <input type="text" id="username" name="username" value="<?= $_SESSION['username']?>" required>
                </div>

                <div class="input-field">
                <label for="pwd">Password</label>
                <input type="password" id="pwd" name="pwd" value="<?= $_SESSION['pwd']?>" required>
                </div>

                <div class="input">
                <label for="formFile" class="form-label">Foto</label>
                <input class="form-control" name="img" value="<?= $_SESSION['img']?>" type="file" id="formFile" required>
                <!-- <label for="img">Foto</label>
                <input type="file" id="img" name="img" value="<?= $_SESSION['img']?>" required> -->
                </div>

            </div>
        </div>

        <div class="details ID">
          
                <div class="btnn">
            <button class="submitBtn">
                <span class="btnText">Submit</span>

            </button>
<br>            
            <div class="cancelBtn">
            <a href="profil.php"> <span class="btnText">Cancel</span></a>
            </div>
           </div>

        </div> 
    </div>

   
        </div> 
    </div>
</form>
</div>
</body>
</html>