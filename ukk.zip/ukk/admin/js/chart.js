var ctx = document.getElementById('myChart').getContext('2d');
var earning = document.getElementById('earning').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'polarArea',
    data: {
        labels: ['Student', 'Staff', 'Admin'],
        datasets: [{
            label: 'Total',
            data: [1500, 500, 1000],
            backgroundColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)'
            ],
        }]
    },
    options: {
        responsive: true,
    }
});


// earning bar

var myChart = new Chart(earning, {
    type: 'bar',
    data: {
        labels: ['Student', 'Staff', 'Admin'],
        datasets: [{
            label: 'Total',
            data: [1500, 500, 1000],
            backgroundColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)'
            ],
        }]
    },
    options: {
        responsive: true,
    }
});
