<?php

include ('../conn.php');
$nisn = $_GET['nisn'];
$query = $conn->query("SELECT * from siswa where nisn='$nisn' ");
$data = $query->fetch();

?>

<?php require ('cek.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/editprof.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Murid - Edit Profil</title>
    <style>
        
    </style>
</head>
<body>
<div class="kontainer">
    <header>Edit Profil</header>

<form action="editprof.php" method="post">
<input type="hidden" name="nisn" value="<?= $nisn ?>">

    <div class="form first">
        <div class="detail personal">

            <div class="fields">
                <div class="input-field">
                <label class="id"  for="nisn">Id</label>
                <input  disabled type="text" id="nisn" name="nisn" value="<?= $data['nisn']?>" required>
                </div>

                <div class="input-field">
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="name" value="<?= $_SESSION['name']?>" required>
                </div>

                <div class="input-field">
                <label for="pass">Password</label>
                <input type="password" id="pass" name="pass" value="<?= $_SESSION['pass']?>" required>
                </div>

                <div class="input">
                <label for="formFile"  class="form-label">Foto</label>
                <input class="form-control" name="imge" value="<?= $_SESSION['imge']?>" type="file" id="formFile" required>
                </div>

            </div>
        </div>

        <div class="details ID">
          
                <div class="btnn">
            <button class="submitBtn">
                <span class="btnText">Submit</span>

            </button>
<br>            
            <div class="cancelBtn">
            <a href="index.php"> <span class="btnText">Cancel</span></a>
            </div>
           </div>

        </div> 
    </div>

   
        </div> 
    </div>
</form>
</div>
</body>
</html>