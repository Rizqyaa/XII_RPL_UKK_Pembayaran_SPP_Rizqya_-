<?php 
	session_start();
    if(!isset($_SESSION["nisn"])) {
    header("Location:../loginus.php");
    }
	?>