<?php

session_start();
    if(!isset($_SESSION["nisn"])) { 
    header("Location:../loginus.php");
    }
$nisn = $_SESSION['nisn'];
include('../conn.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="css/ind.css">
    <link rel="stylesheet" href="css/main.css">


    <title>Murid - History</title>
    <style>
table thead td
{
    font-weight: 600;
}
table tr
{
    color: var(--black1);
    border-bottom: 1px solid rgba(0,0,0,0.1);
}
table tr:last-child
{
    border-bottom: none;
}
table tbody tr:hover
{
    background: var(--l1blue);
    color: var(--white);
}
table tr td
{
    padding: 10px;
}

table tr th:last-child,
table tr td:last-child
{
    text-align: start;
}
table tr th:nth-child(1),
table tr td:nth-child(1)
{
    text-align: start;
}


table tr th:nth-child(2),
table tr td:nth-child(2)
{
    text-align: start;
}
table tr th:nth-child(3),
table tr td:nth-child(3)
{
    text-align: start;
    white-space: nowrap;
}
table tr th:nth-child(4),
table tr td:nth-child(4)
{
    text-align: start;
}
table tr th:nth-child(5),
table tr td:nth-child(5)
{
    text-align: start;
    white-space: nowrap;
}
table tr th:nth-child(6),
table tr td:nth-child(6)
{
    text-align: start;
    white-space: nowrap;
}
table tr th:nth-child(7),
table tr td:nth-child(7)
{
    text-align: start;
    white-space: nowrap;

}
table tr th:nth-child(8),
table tr td:nth-child(8)
{
    text-align: start;
    white-space: nowrap;

}
table tr th:nth-child(9),
table tr td:nth-child(9)
{
    text-align: start;
    white-space: nowrap;

}
</style>
</head>
<body>
<div class="container">
        <div class="nav active">
            <ul>
                <li>
                <a href="#">
                    <span class="icon"><ion-icon name="book-outline"></ion-icon></span>
                    <span class="title">spp</span>
                    <br>
                 </a>
                
                </li>
                <li>
                <a href="index.php">
                    <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                    <span class="title">Dashboard</span>
                </a>
                </li>
                <li>
                <a href="histo.php">
                    <span class="icon"><ion-icon name="refresh"></ion-icon></ion-icon></span>
                    <span class="title">History</span>
                </a>
                </li>
                <li>
                <a href="lout.php">
                    <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                    <span class="title">Sign Out</span>
                </a>
                </li>
                
            </ul>
          
        </div>

        <!-- main -->

       
        <div class= "main active" >
            <div class="topbar">
                <!-- toggle -->
                <div class="toggle">
                <ion-icon name="menu-outline"></ion-icon>
                </div>
                <form action="" method="post">
                </form>
                <!-- user -->
                <div class="user">
                        <a href="index.php">
                            <div class="prof">
                            <img src="../img/<?= $_SESSION['imge'] ;?>" alt="">
                            </div>
                        </a>
                    </div>
            </div>
            <!-- breadcrumb -->
            <nav aria-label="breadcrumb" class="crumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="histo.php"></a>History </li>

            </ol>
            </nav>

          <!-- cards -->
          <!-- <div class="cardBox">
              
            </div> -->

            <!-- chart -->
            <div class="graphbox">

                <div class="tabel">
                    <h2>History Pembayaran</h2>
                    <!-- <div class="divider"></div> -->
                    <table class="table display" id="example">
                        <thead>
                        <tr>
                        <th>No</th>
                        <th>NISN</th>
                        <th>Nama</th>
                        <th>Kelas</th>
                        <th>Tahun SPP</th>
                        <th>Tahun & Bulan Yang Dibayar</th>
                        <th>Yang Harus Dibayar</th>
                        <th>Sudah Dibayar</th>
                        <th>Tanggal Bayar</th>
                        <th>Petugas</th>

                        </tr>
                        <?php
                        $no =1;
                        $query = $conn->query("SELECT * FROM pembayaran,siswa,kelas,spp,petugas WHERE pembayaran.nisn=siswa.nisn AND siswa.idkls=kelas.idkls AND pembayaran.idSpp=spp.idSpp AND pembayaran.idPetugas=petugas.idPetugas AND pembayaran.nisn='$nisn' ORDER BY tglBayar DESC")->fetchAll();
                        foreach ($query as $data):
                        
                        ?>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $data['nisn'] ?></td>
                                <td><?= $data['name'] ?></td>
                                <td><?= $data['namaKelas'] ?> <?= $data['kompetensiKeahlian'] ?></td>
                                <td><?= $data['tahun'] ?></td>
                                <td><?= $data['tahun_dibayar'] ?> | <?= $data['bulan_dibayar'] ?></td>
                                <td><?= number_format($data['nominal'],2,',','.'); ?> </td>    
                                <td><?= number_format($data['jumlah_bayar'],2,',','.'); ?> </td> 
                                <td><?= $data['tglBayar'] ?></td>
                                <td><?= $data['nama'] ?></td>
                            </tr>
                        </tbody>
                        <?php endforeach ?>
                    </table>
                </div>
                
            </div>



    </div>






        <!-- script -->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {
    $('#example').DataTable();
});
</script>
    <script>
        // menu toggle
        let toggle = document.querySelector('.toggle');
        let nav = document.querySelector('.nav');
        let main = document.querySelector('.main');

        toggle.onclick = function(){
        nav.classList.toggle('active');
        main.classList.toggle('active')

        }
        // hovered class in selected list item
        let list = document.querySelectorAll('.nav li');
        function activeLink(){
            list.forEach((item) =>
            item.classList.remove('hovered'));
            this.classList.add('hovered');
        }
        list.forEach((item) =>
        item.addEventListener('mouseover', activeLink));
    </script>


</body>
</html>