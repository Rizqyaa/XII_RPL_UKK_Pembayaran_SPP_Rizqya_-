<?php
session_start();
unset($_SESSION["nisn"]);
header("location:../loginus.php");
?>