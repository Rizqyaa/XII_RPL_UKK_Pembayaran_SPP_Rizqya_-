
<?php 
include('../conn.php');

$nisn = $_POST['nisn'];
$name = $_POST['name'];
$pass = $_POST['pass'];
$img = $_POST['imge'];

  $query = $conn->query("UPDATE `siswa` SET `name`='$name',`pass`='$pass',`imge`='$img' WHERE `nisn`='$nisn' ");

  if($query){
     header("Location:index.php");
  }
  else{ 
    header("Location:fedprof.php?error=$pesan_error");
  }

?>